// Modules
const path = require('path');
const {pathsToModuleNameMapper} = require('ts-jest/utils');

// TypeScript configuration
const {compilerOptions} = require('./tsconfig.json');

/**
 * The list of packages in node_modules to transform using babel.
 * If you encounter the error `SyntaxError: Cannot use import statement outside a module` add the culprit from node_modules in the list.
 */
const NODE_MODULES_TO_TRANSFORM = [];

// Defines the Jest configuration.
// See https://jestjs.io/docs/en/configuration#options
module.exports = {
	/**
	 * The directory where Jest should store its cached dependency information.
	 * See https://jestjs.io/docs/en/configuration#cachedirectory-string
	 */
	cacheDirectory: './node_modules/.cache/jest',

	/**
	 * Automatically clear mock calls and instances before every test.
	 * See https://jestjs.io/docs/en/configuration#clearmocks-boolean
	 */
	clearMocks: true,

	/**
	 * An array of glob patterns indicating a set of files for which coverage information should be collected.
	 * See https://jestjs.io/docs/en/configuration#collectcoveragefrom-array
	 */
	collectCoverageFrom: ['./packages/**/src/**/*.{ts,tsx}'],

	/**
	 * A list of reporter names that Jest uses when writing coverage reports.
	 * See https://jestjs.io/docs/en/configuration#coveragereporters-arraystring
	 */
	coverageReporters: ['lcov', 'clover'],

	/**
	 * An array of file extensions your modules use.
	 * See https://jestjs.io/docs/en/configuration#modulefileextensions-arraystring
	 */
	moduleFileExtensions: ['js', 'ts', 'jsx', 'tsx'],

	/**
	 * A map from regular expressions to module names that allow to stub out resources,
	 * like images or styles with a single module.
	 *
	 * See https://jestjs.io/docs/en/configuration#modulenamemapper-objectstring-string
	 */
	moduleNameMapper: pathsToModuleNameMapper(compilerOptions.paths, {
		prefix: __dirname + path.sep,
	}),

	/**
	 * A preset that is used as a base for Jest's configuration.
	 * See https://jestjs.io/docs/en/configuration#preset-string
	 */
	preset: 'ts-jest',

	/**
	 * The test environment that will be used for testing.
	 * See https://jestjs.io/docs/en/configuration#testenvironment-string
	 */
	testEnvironment: 'jsdom',

	/**
	 * An array of regexp pattern strings that are matched against all test paths before executing the test.
	 * See https://jestjs.io/docs/en/configuration#testpathignorepatterns-arraystring
	 */
	testPathIgnorePatterns: ['/node_modules/', '/build/', '/templates/'],

	/**
	 * The pattern or patterns Jest uses to detect test files.
	 * See https://jestjs.io/docs/en/configuration#testregex-string--arraystring
	 */
	testRegex: '/__tests__/.*\\.(unit|integ)\\.tsx?$',

	/**
	 * A map from regular expressions to paths to transformers.
	 * See https://jestjs.io/docs/configuration#transform-objectstring-pathtotransformer--pathtotransformer-object
	 */
	transform: {
		// The `ts-jest` preset will automagically add '\\.ts$': 'ts-jest'
		'\\.js$': 'babel-jest',
	},

	/**
	 * An array of regexp pattern strings that are matched against all source file paths before transformation.
	 * See https://jestjs.io/docs/configuration#transformignorepatterns-arraystring
	 */
	transformIgnorePatterns: [
		`/node_modules/(?!${NODE_MODULES_TO_TRANSFORM.join('|')})`,
	],

	/**
	 * An array of regexp pattern strings that are matched against all test paths before watching the test.
	 * See https://jestjs.io/docs/configuration#watchpathignorepatterns-arraystring
	 */
	watchPathIgnorePatterns: ['/node_modules/', '/build/', '/templates/'],
};
