/* eslint-disable no-console */
/**
 * Generate configuration from Black Keys
 *
 * When in development, expects the `SETTING_USER` variable in order to set the good urls.
 * It may have some environment variables:
 * - BUILD_ID: reflected in the config release property. Mainly used for log purposes.
 * - SETTING_USER: in development, use this user to call api from. e.g SETTING_USER=devtest => devtest-www.deezerdev.com.
 * - OVERRIDE_ASSETS_PATH: override the path to serve assets from. Used for preview urls in PR.
 */

const {execSync} = require('child_process');
const {getConsulAddressByPlatform} = require('./black-keys/black-keys');

const {DEEZER_PLATFORM, SETTING_USER} = process.env;

const consulUrl = getConsulAddressByPlatform(DEEZER_PLATFORM || 'deezerdev');

// Default to `devtest` user in dev
if ((!DEEZER_PLATFORM || DEEZER_PLATFORM === 'deezerdev') && !SETTING_USER) {
	process.env.SETTING_USER = 'devtest';
}

console.log('Getting config from', consulUrl);

execSync(`consul-template \
    -consul-addr="${consulUrl}" \
    -log-level info \
    -once \
    -config black-keys/consul-template.hcl \
    -template "black-keys/config.json.tpl:./packages/player/src/config/config.json" \
`);

console.log('Done');
