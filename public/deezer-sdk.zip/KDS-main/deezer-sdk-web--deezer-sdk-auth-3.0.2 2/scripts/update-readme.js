// Modules
const path = require('path');
const fs = require('fs');
const {spawnSync} = require('child_process');

// Options
const readmeFile = path.join(__dirname, '../README.md');
const templateBegin = '<!-- begin:packages -->';
const templateEnd = '<!-- end:packages -->';

/**
 * Returns a detailed package list by scope.
 */
function getPackagesByScope() {
	const lerna = spawnSync('lerna', ['list', '--json'], {
		stdio: 'pipe',
	});

	if (lerna.error) {
		throw lerna.error;
	}

	const result = {};
	const packages = JSON.parse(lerna.stdout);

	packages.forEach((pkg) => {
		const scope = path.basename(path.join(pkg.location, '..'));

		if (!result[scope]) {
			result[scope] = [];
		}

		result[scope].push({
			name: pkg.name,
			version: pkg.version,
			location: pkg.location,
		});
	});

	return result;
}

/**
 * Returns the generated markdown for the package list by scope.
 */
function getPackagesMarkdown() {
	let markdown = '';

	for (let [scope, packages] of Object.entries(getPackagesByScope())) {
		markdown += `### ${scope[0].toUpperCase() + scope.slice(1)}\n`;
		markdown += '| Name | Version | Status | Description |\n';
		markdown += '| --- | --- | --- | --- |\n';

		packages.forEach((pkg) => {
			const pkgLink = path.relative(path.join(__dirname, '..'), pkg.location);

			const pkgVersion = fs.existsSync(path.join(pkgLink, 'CHANGELOG.md'))
				? `[${pkg.version}](${pkgLink}/CHANGELOG.md)`
				: pkg.version;

			const {description} = require(`${pkg.location}/package.json`);

			markdown += `| [${pkg.name}](${pkgLink}) `;
			markdown += `| ${pkgVersion} `;
			markdown += `| ${pkg.private ? 'Private' : 'Public'} `;
			markdown += `| ${description} |\n`;
		});

		markdown += '\n';
	}

	return markdown.replace(/\n+$/, '');
}

// Generates the output to be written in the README.md file.
const readmeContent = fs.readFileSync(readmeFile, {encoding: 'utf-8'});
const templateContent = `${templateBegin}\n${getPackagesMarkdown()}\n${templateEnd}`;
const output = readmeContent.replace(
	new RegExp(`${templateBegin}([\\s\\S]*?)${templateEnd}`, 'gm'),
	templateContent,
);

// Writes new README.md file.
fs.writeFileSync(readmeFile, output);
