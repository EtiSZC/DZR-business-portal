/**
 * Returns the consul adress for a particular platform
 * @param {('docker'|'stack'|'deezerdev'|'deezerprod')} platform
 */
function getConsulAddressByPlatform(platform) {
	switch (platform) {
		case 'docker':
		case 'stack':
			return 'http://black-keys-consul:8500';

		case 'deezerdev':
			return 'https://dev-consul.deez.re';

		case 'deezerprod':
			return 'https://consul.deez.re';

		default:
			throw new Error(
				`Argument platform incorrect. Expected one of ('docker'|'stack'|'deezerdev'|'deezerprod'), recieved ${platform}`,
			);
	}
}

module.exports = {getConsulAddressByPlatform};
