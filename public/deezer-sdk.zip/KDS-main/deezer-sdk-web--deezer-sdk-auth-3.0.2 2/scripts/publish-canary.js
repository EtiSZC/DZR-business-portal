const {execSync} = require('child_process');
const {DEBUG} = process.env;

const lastCommonAncestor = execSync('git merge-base origin/master HEAD', {
	encoding: 'utf8',
});

DEBUG &&
	console.debug(
		'last common ancestor with origin/master is',
		lastCommonAncestor,
	);

let modifiedPackages = execSync(
	`npx lerna list --since ${lastCommonAncestor}`,
	{
		encoding: 'utf8',
		stdio: 'pipe',
	},
)
	.trim()
	.split('\n')
	.join(',');

if (!modifiedPackages) {
	DEBUG && console.debug('No packages modified found');
	process.exit();
}

DEBUG && console.debug('Modified packages are', modifiedPackages);

const commitID = execSync('git rev-parse --short HEAD', {
	encoding: 'utf8',
	stdio: 'pipe',
}).trim();

const publishStdout = execSync(
	`npm run release --ignore-scripts -- --yes --canary --preid=${commitID} --force-publish=${modifiedPackages}`,
	{
		encoding: 'utf8',
		stdio: 'pipe',
	},
);

const [, publishedPackages] = publishStdout.split('Successfully published:');

console.log(`Published modules are\n${publishedPackages}`);
