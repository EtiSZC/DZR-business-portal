module.exports = function getBabelConfig(api) {
	const useESModules = api.env('esm');

	const presets = [
		[
			'@babel/preset-env',
			{
				bugfixes: true,
				loose: true,
				browserslistEnv: api.env(),
				modules: useESModules ? false : 'commonjs',
			},
		],
		'@babel/preset-typescript',
	];

	const plugins = [
		['@babel/plugin-proposal-class-properties', {loose: true}],
		['@babel/plugin-proposal-object-rest-spread', {loose: true}],
		['@babel/plugin-proposal-private-property-in-object', {loose: true}],
		[
			'@babel/plugin-transform-runtime',
			{
				useESModules,
				version: '^7.12.5',
			},
		],
		['inline-json-import'],
	];

	return {
		env: {
			test: {
				presets: [['@babel/preset-env', {targets: {node: 'current'}}]],
			},
		},
		ignore: ['**/__tests__/**/*'],
		plugins,
		presets,
	};
};
