{
    "host_authent": "{{ key (plugin "dzr-key" "hosts/authent") }}",
    "host_pipe": "{{ key (plugin "dzr-key" "hosts/pipe") }}",
    "url_media_service": "https://{{ key (plugin "dzr-key" "service-endpoints/media/service-url") | replaceAll "https://" ""}}",
    "url_rec": "https://{{ key (plugin "dzr-key" "hosts/rec") }}/1.0/events/",
    "url_relive": "wss://{{ key (plugin "dzr-key" "hosts/live_ssl") }}/ws/"
}
