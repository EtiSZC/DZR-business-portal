consul {
    retry {
        attempts = 3
    }
}
 vault {
    renew_token = false
    retry {
        attempts = 3
    }
}
