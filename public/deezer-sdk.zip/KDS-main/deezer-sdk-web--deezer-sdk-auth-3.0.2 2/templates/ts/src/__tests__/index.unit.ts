// Tests
import {{pascalCase name}} from '../';

describe('{{name}}', () => {
	it('should not throw when instantiated', () => {
		expect(() => {
			new {{pascalCase name}}();
		}).not.toThrow();
	});
});
