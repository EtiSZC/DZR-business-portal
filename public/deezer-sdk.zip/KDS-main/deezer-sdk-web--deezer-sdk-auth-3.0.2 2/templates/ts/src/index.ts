{{#if interface }}
import {{ pascalCase interface.interfaceName }}Interface from '{{interface.packageName}}';

{{/if}}
export default class {{ pascalCase name }} {{#if interface }}implements {{pascalCase interface.interfaceName}}Interface {{/if}}{

}
