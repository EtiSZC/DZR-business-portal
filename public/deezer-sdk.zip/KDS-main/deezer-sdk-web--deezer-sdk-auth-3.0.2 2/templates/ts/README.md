# `{{kebabCase name}}`

{{description}}

## Installation

```
npm i @deezer/{{kebabCase name}}
```

## Usage

#TODO

```tsx
```
