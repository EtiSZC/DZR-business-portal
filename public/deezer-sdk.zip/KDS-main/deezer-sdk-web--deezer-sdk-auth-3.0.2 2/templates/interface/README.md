# `{{kebabCase name}}-interface`

{{description}}

## Installation

```
npm i @deezer/{{kebabCase name}}-interface
```

## Usage

Just import and implement the interface

```ts
import {{pascalCase name}} from '@deezer/{{kebabCase name}}-interface';

class {{pascalCase name}}OfTheFuture implements {{pascalCase name}} {
	// implement the things =)
}
```
