export default interface {{ pascalCase name }}Interface {

}
