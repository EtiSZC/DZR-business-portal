const path = require('path');
const toKebabCase = (str) => {
	return str
		.match(/[A-Z]{2,}(?=[A-Z][a-z]+[0-9]*|\b)|[A-Z]?[a-z]+[0-9]*|[A-Z]|[0-9]+/g)
		.map((x) => x.toLowerCase())
		.join('-');
};

const prettier = require('prettier');
const {execSync} = require('child_process');

const prettify = async (src, destFile) => {
	const configFile = await prettier.resolveConfigFile();
	const config = await prettier.resolveConfig(configFile);
	const fileInfo = await prettier.getFileInfo(destFile);
	return prettier.format(src, {...config, parser: fileInfo.inferredParser});
};

module.exports = (
	/** @type {import('plop').NodePlopAPI} */
	plop,
) => {
	plop.setGenerator('interface', {
		description: 'Shareable interface',
		prompts: [
			{
				type: 'input',
				name: 'name',
				validate: (s) => !!s.length,
				message: 'Interface name (e.g. Config):',
			},
			{
				type: 'input',
				name: 'description',
				validate: (s) => !!s.length,
				message:
					'Short description of the interface, will be used for README and package.json:',
			},
		],
		actions: [
			{
				type: 'addMany',
				destination: 'packages/{{kebabCase name}}-interface/',
				templateFiles: 'templates/interface/**/*',
				base: 'templates/interface/',
			},
			{
				type: 'modify',
				path: 'tsconfig.json',
				transform: async (tsConfig, answers) => {
					const data = JSON.parse(tsConfig);
					data.compilerOptions.paths[
						`@deezer/${toKebabCase(answers.name)}-interface`
					] = [`packages/${toKebabCase(answers.name)}-interface/lib`];
					const finalPaths = {};
					Object.keys(data.compilerOptions.paths)
						.sort()
						.forEach((key) => {
							data.compilerOptions.paths[key].sort();
							finalPaths[key] = data.compilerOptions.paths[key];
						});
					data.compilerOptions.paths = finalPaths;
					return prettify(JSON.stringify(data, null, '\t'), 'tsconfig.json');
				},
			},
		],
	});

	plop.setGenerator('ts-package', {
		description: 'Standard TypeScript package',
		prompts: [
			{
				type: 'input',
				name: 'name',
				validate: (s) => !!s.length,
				message: 'Package name (e.g. Config):',
			},
			{
				type: 'list',
				name: 'interface',
				message:
					'Optional interface to implement (if you need an interface, make sure to create it before):',
				choices: (answers) => {
					const tsConfig = require('./tsconfig.json');
					const paths = tsConfig.compilerOptions.paths;
					const choices = Object.keys(paths)
						.map((packageName) => {
							if (packageName.endsWith('-interface')) {
								const shortName = packageName
									.replace('@deezer/', '')
									.replace('-interface', '');

								const packageInfo = require('./' +
									path.join(paths[packageName][0], '../package.json'));

								return {
									name: packageName,
									value: {
										packageName,
										packageVersion: packageInfo.version,
										interfaceName: shortName,
										relativePathToInterface: path.relative(
											path.join('packages', answers.name),
											path.join(paths[packageName][0], '../'),
										),
									},
									short: packageName,
								};
							}
						})
						.filter((c) => !!c);

					choices.push({
						name: 'None',
						value: false,
					});
					return choices;
				},
			},
			{
				type: 'confirm',
				name: 'isDep',
				message:
					'Do you intend to use this package, in the short term, as a dependency for another one in this repository?',
			},
			{
				type: 'input',
				name: 'description',
				validate: (s) => !!s.length,
				message:
					'Short description of the package, will be used for README and package.json:',
			},
		],
		actions: [
			{
				type: 'addMany',
				destination: 'packages/{{kebabCase name}}/',
				templateFiles: 'templates/ts/**/*',
				base: 'templates/ts/',
			},
			{
				type: 'modify',
				path: 'tsconfig.json',
				skip: (answers) => !answers.isDep,
				transform: (tsConfig, answers) => {
					const sourceFolder = answers.name.includes('interface')
						? 'lib'
						: 'src';
					const data = JSON.parse(tsConfig);
					data.compilerOptions.paths[`@deezer/${toKebabCase(answers.name)}`] = [
						`packages/${toKebabCase(answers.name)}/${sourceFolder}`,
					];

					data.compilerOptions.paths = JSON.parse(
						JSON.stringify(
							data.compilerOptions.paths,
							Object.keys(data.compilerOptions.paths).sort(),
						),
					);

					return prettify(JSON.stringify(data, null, '\t'), 'tsconfig.json');
				},
			},
			function customAction() {
				execSync('npm install');
			},
		],
	});
};
