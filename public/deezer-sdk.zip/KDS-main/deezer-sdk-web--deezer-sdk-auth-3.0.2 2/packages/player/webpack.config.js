const webpack = require('webpack');
const path = require('path');
const BundleAnalyzerPlugin =
	require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

const umdConfig = {
	mode: 'development',
	entry: './src/index.ts',
	output: {
		publicPath: '',
		globalObject: 'this',
		filename: 'index.js',
		path: path.resolve(__dirname, 'build/umd'),
		library: {
			type: 'umd',
		},
	},
	devtool: 'source-map',
	module: {
		rules: [
			{
				test: /\.tsx?$/,
				use: {
					loader: 'babel-loader',
				},
				exclude: /node_modules/,
			},
		],
	},
	optimization: {
		minimize: false
	},
	plugins: [
		// Also add lazy loaded chunks to the bundle
		new webpack.optimize.LimitChunkCountPlugin({
			maxChunks: 1,
		}),
		new webpack.EnvironmentPlugin(['npm_package_name', 'npm_package_version']),
		process.env.ANALYZE && new BundleAnalyzerPlugin(),
	].filter(Boolean),
	resolve: {
		extensions: ['.tsx', '.ts', '.js'],
		fallback: {
			// Disable node `crypto` as webpack may think it is needed because of crypto-blowfish
			crypto: false,
			url: require.resolve('url/'),
		},
	},
	target: ['web'],
};

module.exports = umdConfig