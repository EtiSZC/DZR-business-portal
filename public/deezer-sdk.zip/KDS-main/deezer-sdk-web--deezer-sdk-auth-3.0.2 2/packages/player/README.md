# `sdk-player`

Deezer Web SDK

## Installation

```
npm i @deezer/sdk-player
```

## Usage

#TODO

# Release

## Releasing for partners

Releases are made locally for now, you need to prepare your environment for the release (see section below)

### Releasing (requires preparing environment)

- Change the sdk-player `package.json` version number
- Run `npm run release` in `sdk-player` directory

### Prepare your environment for the release

[DeezerPPS JFrog Registry](https://deezerpps.jfrog.io/ui/repos/tree/General/web-sdk)

- Create an account on the DeezerPPS registry
- Ask Partnership Integration (Camille Blin) to give your account read&write access for web-sdk package
- Initialize your custom pps.npmrc: `npm run generate:npmrc` in `sdk-player` directory

> Note: cannot use `lerna run` for this command because it prompts in terminal questions

## TypeScript specificities

The types are generated using the `npm run build:types` and `npm run postbuild:types` commands.

To obfuscate the type definitions, we use [api-extractor](https://api-extractor.com). It allows us to hide Deezer's internal dependencies from the user.
To do so we list our internal packages in the `api-extractor.jsonc` file:

```json
  "bundledPackages": [
    "@deezer-kmpp/XPlayer",
    "@deezer/deezer-kmp-player",
    ...
  ],
```

This list needs to be updated when a new package is added.

The type definitions required by api-extractor are generated in `build/tmp` directory and are excluded from the release.
