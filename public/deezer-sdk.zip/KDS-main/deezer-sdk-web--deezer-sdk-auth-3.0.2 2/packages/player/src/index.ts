import {
	AdsMediaRendererApi,
	AdsMediaRendererStatus,
	KMPP as kmp,
	KMPBatchProvider,
} from '@deezer/deezer-kmp-player';
import {AdsMediaProviderApi} from '@deezer/deezer-kmp-player/build/types/ads/KMPAdsMediaProvider';

export {
	MediaRequest,
	RetrieveTrackMediaMetadataAction,
	User,
} from '@deezer/deezer-kmp-player';

export {DeezerPlayer, DeezerPlayerStates} from './DeezerPlayer';
export type {DeezerPlayerState} from './DeezerPlayer';
export {DeezerRepeatModes} from './DeezerQueueList';
export type {DeezerRepeatMode} from './DeezerQueueList';
export {DeezerAudioQualities} from './DeezerPlayerSettings';
export type {DeezerAudioQuality} from './DeezerPlayerSettings';
export type DeezerBatchProvider = KMPBatchProvider;
export type DeezerAdsMediaProvider = AdsMediaProviderApi;
export type DeezerAdsMediaRenderer = AdsMediaRendererApi;
export type DeezerAdsMediaRendererStatus = AdsMediaRendererStatus;

export const Playable = kmp.player.models.Playable;
export const PlayableIdentifier = kmp.player.models.PlayableIdentifier;
export const PlayableType = kmp.player.models.PlayableType;
export const StreamContext = kmp.player.models.StreamContext;
export const ListenType = kmp.player.models.ListenType;
export const PlayerPlaybackState = kmp.player.models.PlayerPlaybackState;
export const BatchParams = kmp.queue.api.BatchParams;
export const BatchQueueState = kmp.queue.api.BatchQueueState;
export const CancellableOnce = kmp.helper.CancellableOnce;
export const copyToMPList = kmp.mp.copyToMPList;
export type BatchProviderListener = kmp.queue.api.BatchProviderListener;
export type Cancellable = kmp.helper.Cancellable;
