export interface IDeezerPlayerAction {
	play(): void;
	pause(): void;
	previous(): void;
	next(): void;
	seek(positionInSeconds: number): void;
	goto(index: number, startPositionInSeconds: number): void;
	setVolume(volume: number): void;
	getVolume(): number;
	setPlaybackSpeed(speed: number): void;
	getPlaybackSpeed(): number;
	subscribeState(listener: () => void): void;
}
