import {KMPP as kmp} from '@deezer/deezer-kmp-player';

export const DeezerRepeatModes = {
	NONE: null,
	ONE: 'One',
	ALL: 'All',
} as const;

export type DeezerRepeatMode =
	typeof DeezerRepeatModes[keyof typeof DeezerRepeatModes];

class DeezerQueueCapabilities {
	private player: kmp.player.api.PlayerApi;

	constructor(player: kmp.player.api.PlayerApi) {
		this.player = player;
	}

	getAllowedRepeatModes(): DeezerRepeatMode[] {
		const kmpModes = kmp.mp.copyToJsArray(
			this.player.playerState.value.capabilities.allowedRepeatModes,
		);
		return [
			DeezerRepeatModes.NONE,
			...kmpModes.map((mode) => {
				switch (mode) {
					case kmp.player.models.RepeatMode.One:
						return DeezerRepeatModes.ONE;
					case kmp.player.models.RepeatMode.All:
						return DeezerRepeatModes.ALL;
					default:
						return DeezerRepeatModes.NONE;
				}
			}),
		];
	}

	canUpdateRepeatMode(): boolean {
		return (
			kmp.mp.copyToJsArray(
				this.player.playerState.value.capabilities.allowedRepeatModes,
			).length > 0
		);
	}

	canShuffle(): boolean {
		return this.player.playerState.value.capabilities.canShuffle;
	}
}
export class DeezerQueueList {
	private player: kmp.player.api.PlayerApi;
	private limiter: kmp.player.permissions.limiter.PermissionsLimiterApi;
	private canAccessQueue = true;
	private queueUpdateSubscriptions: Set<() => void> = new Set();
	private shuffleStateSubscriptions: Set<(shuffled: boolean) => void> =
		new Set();
	private repeatModeSubscriptions: Set<(mode: DeezerRepeatMode) => void> =
		new Set();

	constructor(
		player: kmp.player.api.PlayerApi,
		limiter: kmp.player.permissions.limiter.PermissionsLimiterApi,
	) {
		this.player = player;
		this.limiter = limiter;
		this.initializeSubscriptions();
	}

	private initializeSubscriptions() {
		this.player.playerState.subscribe(
			() => {
				this.notifyQueueSubscribers();
				this.notifyShuffleSubscribers();
				this.notifyRepeatModeSubscribers();
			},
			() => void 0,
		);

		this.limiter?.permissionsLimiterState.subscribe(
			(state) => {
				console.log('permissionsLimiterState', state);
				this.canAccessQueue = state.canAccessQueue;
			},
			() => void 0,
		);
	}

	private notifyQueueSubscribers() {
		this.queueUpdateSubscriptions.forEach((listener) => listener());
	}

	private notifyShuffleSubscribers() {
		const shuffled = this.isShuffled();
		this.shuffleStateSubscriptions.forEach((listener) => listener(shuffled));
	}

	private notifyRepeatModeSubscribers() {
		const repeatMode = this.getRepeatMode();
		this.repeatModeSubscriptions.forEach((listener) => listener(repeatMode));
	}

	subscribeOnQueueUpdated(listener: () => void) {
		this.queueUpdateSubscriptions.add(listener);
	}

	unsubscribeOnQueueUpdated() {
		this.queueUpdateSubscriptions.clear();
	}

	subscribeOnShuffleStateChanged(listener: (shuffled: boolean) => void) {
		this.shuffleStateSubscriptions.add(listener);
	}

	unsubscribeOnShuffleStateChanged() {
		this.shuffleStateSubscriptions.clear();
	}

	subscribeOnRepeatModeChanged(listener: (mode: DeezerRepeatMode) => void) {
		this.repeatModeSubscriptions.add(listener);
	}

	unsubscribeOnRepeatModeChanged() {
		this.repeatModeSubscriptions.clear();
	}

	getQueueCapabilities(): DeezerQueueCapabilities {
		return new DeezerQueueCapabilities(this.player);
	}

	setQueue(playables: kmp.player.models.Playable[]) {
		this.player.dispatchAction(
			kmp.player.api.PlayerAction.SetBasicQueue.WithDefaults(
				kmp.mp.copyToMPList(playables),
				0,
			),
		);
	}

	setInfiniteQueue(playables: kmp.player.models.Playable[]) {
		this.player.dispatchAction(
			kmp.player.api.PlayerAction.SetInfiniteQueue.WithDefaults(
				kmp.mp.copyToMPList(playables),
				0,
			),
		);
	}

	add(playables: kmp.player.models.Playable[], index?: number) {
		if (!this.canAccessQueue) {
			return;
		}
		this.player.dispatchAction(
			new kmp.player.api.PlayerAction.AddPlayables(
				kmp.mp.copyToMPList(playables),
				index,
			),
		);
	}

	removeAt(index: number) {
		if (!this.canAccessQueue) {
			return;
		}
		this.player.dispatchAction(new kmp.player.api.PlayerAction.RemoveAt(index));
	}

	move(fromPosition: number, toPosition: number) {
		if (!this.canAccessQueue) {
			return;
		}
		this.player.dispatchAction(
			new kmp.player.api.PlayerAction.Reorder(fromPosition, toPosition),
		);
	}

	getCurrentIndex() {
		return this.player.playerState.value.queueCurrentIndex;
	}

	getCurrentMedia() {
		const currentMediaIndex = this.getCurrentIndex();
		if (currentMediaIndex === null || currentMediaIndex === undefined) {
			return null;
		}
		return this.getAllMedia()[currentMediaIndex];
	}

	getAllMedia() {
		return kmp.mp.copyToJsArray(this.player.playerState.value.queueItems);
	}

	setRepeatMode(mode: DeezerRepeatMode) {
		let kmpMode: kmp.player.models.RepeatMode | null = null;
		switch (mode) {
			case DeezerRepeatModes.ONE:
				kmpMode = kmp.player.models.RepeatMode.One;
				break;
			case DeezerRepeatModes.ALL:
				kmpMode = kmp.player.models.RepeatMode.All;
				break;
		}
		this.player.dispatchAction(
			new kmp.player.api.PlayerAction.SetRepeatMode(kmpMode),
		);
	}

	getRepeatMode(): DeezerRepeatMode {
		const kmpMode = this.player?.playerState.value.repeatMode;
		switch (kmpMode) {
			case kmp.player.models.RepeatMode.One:
				return DeezerRepeatModes.ONE;
			case kmp.player.models.RepeatMode.All:
				return DeezerRepeatModes.ALL;
			default:
				return DeezerRepeatModes.NONE;
		}
	}

	setShuffle(shuffled: boolean) {
		this.player.dispatchAction(
			new kmp.player.api.PlayerAction.SetShuffle(shuffled),
		);
	}

	isShuffled(): boolean {
		return this.player?.playerState.value.shuffled;
	}

	canEdit(): boolean {
		if (
			!this.limiter ||
			this.limiter.permissionsLimiterState.value === undefined
		) {
			return false;
		}

		return this.canAccessQueue;
	}
}
