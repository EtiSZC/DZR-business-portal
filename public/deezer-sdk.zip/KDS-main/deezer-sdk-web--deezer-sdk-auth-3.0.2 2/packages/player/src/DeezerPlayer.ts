import {
	createPlayer,
	User,
	RetrieveTrackMediaMetadataAction,
	AdsMediaRendererApi,
} from '@deezer/deezer-kmp-player';

import {
	DeezerPlayerSettings,
	DeezerAudioQuality,
	DeezerAudioQualities,
} from './DeezerPlayerSettings';
import {DeezerQueueList} from './DeezerQueueList';

import {IDeezerPlayerAction} from './DeezerPlayerAction';
import {
	IDeezerPlayerInfos,
	IDeezerPlayerProgress,
	IDeezerPlayerFailure,
	IDeezerLimitationState,
	IDeezerPlayerLimitationListener,
	IDeezerCurrentMedia,
} from './DeezerPlayerInfos';
import {KMPP as kmp} from '@deezer/deezer-kmp-player';
import {DeezerBatchProvider} from '.';
import {AdsMediaProviderApi} from '@deezer/deezer-kmp-player/build/types/ads/KMPAdsMediaProvider';

export interface IDeezerPlayerCapabilities {
	canPlay(): boolean;
	canPause(): boolean;
	canSeek(): boolean;
	canNext(): boolean;
	canPrevious(): boolean;
	canSetPlaybackSpeed(): boolean;
}

export const DeezerPlayerStates = {
	IDLE: 'Idle',
	BUFFERING: 'Buffering',
	PREPARING: 'Preparing',
	READY: 'Ready',
	PLAYING: 'Playing',
	PAUSED: 'Paused',
	ENDED: 'Ended',
} as const;

export type DeezerPlayerState =
	| typeof DeezerPlayerStates[keyof typeof DeezerPlayerStates]
	| undefined;
export interface IDeezerPlaybackState {
	isPaused(): () => boolean;
	playerState: DeezerPlayerState;
	capabilities: IDeezerPlayerCapabilities;
	isInAudioBreak: boolean;
}

type DeezerPlayerConfig = {
	app: {
		name: string;
		version: string;
	};
	trackMediaRequestProvider: RetrieveTrackMediaMetadataAction;
	batchProvider?: DeezerBatchProvider;
	userProvider: () => Promise<User>;
	adsMediaProvider: AdsMediaProviderApi;
	adsMediaRenderer: AdsMediaRendererApi;
	defaultAudioQuality?: DeezerAudioQuality;
	debug?: boolean;
};

interface IDeezerPlayer extends IDeezerPlayerAction, IDeezerPlayerInfos {
	player?: kmp.player.api.PlayerApi;
	settings?: DeezerPlayerSettings;
	queueList: DeezerQueueList;
}

export class DeezerPlayer implements IDeezerPlayer {
	player?: kmp.player.api.PlayerApi;
	user?: User;
	limiter?: kmp.player.permissions.limiter.PermissionsLimiterApi;
	settings?: DeezerPlayerSettings;
	queueList!: DeezerQueueList;
	stateListeners: Set<() => void> = new Set();
	playbackProgressListeners: Set<(progress: IDeezerPlayerProgress) => void> =
		new Set();
	playbackStateListeners: Set<(playbackState: IDeezerPlaybackState) => void> =
		new Set();
	playerErrorListeners: Set<(error: IDeezerPlayerFailure) => void> = new Set();

	playerLimitationListeners: Set<IDeezerPlayerLimitationListener> = new Set();

	currentMediaChangedListeners: Set<(media: IDeezerCurrentMedia) => void> =
		new Set();

	debug?: boolean;

	async init(config: DeezerPlayerConfig) {
		const defaultConfig: Partial<DeezerPlayerConfig> = {
			app: {
				name: 'DeezerPlayer',
				version: '1.0.0',
			},
			defaultAudioQuality: DeezerAudioQualities.MP3_128,
		};

		const finalConfig = {...defaultConfig, ...config};

		const {player, limiter, setEncoding} = await createPlayer({
			app: finalConfig.app,
			logger: this.debug ? console : undefined,
			onSIPMessage: () =>
				alert('Playback paused because another device launched a playback'),
			getMediaRequest: finalConfig.trackMediaRequestProvider,
			urlProvider: () => ({
				logger: 'https://rec.deezer.com/1.0/events/',
				mediaService: 'https://media.deezer.com',
				webSocket: 'wss://live.deezer.com/ws/',
			}),
			endpoint: 'https://pipe.deezer.com/api',
			userProvider: finalConfig.userProvider,
			adsMediaProvider: finalConfig.adsMediaProvider,
			adsMediaRenderer: finalConfig.adsMediaRenderer,
			volume: 0.3,
			batchProvider: finalConfig.batchProvider,
		});

		this.player = player;
		this.user = await finalConfig.userProvider();
		this.limiter = limiter;
		this.queueList = new DeezerQueueList(player, limiter);
		this.settings = new DeezerPlayerSettings(player, setEncoding);

		this.settings.updateAudioQuality(finalConfig.defaultAudioQuality);

		this.debug = finalConfig.debug;

		this.initializeSubscriptions();

		if (this.debug) {
			console.log('DeezerPlayer initialized with debug mode', {
				config: finalConfig,
				player,
			});
		}
	}

	play() {
		this.player?.dispatchAction(kmp.player.api.PlayerAction.Play);
	}

	pause() {
		this.player?.dispatchAction(kmp.player.api.PlayerAction.Pause);
	}

	previous() {
		this.player?.dispatchAction(kmp.player.api.PlayerAction.Previous);
	}

	next() {
		this.player?.dispatchAction(kmp.player.api.PlayerAction.Next);
	}

	seek(positionInSeconds: number) {
		if (!this.player?.playerState.value.capabilities.canSeek) {
			throw new Error('Cannot seek in the current state');
		}

		const durationInSeconds = this.getDuration();
		const position = Math.max(
			0,
			Math.min(durationInSeconds, positionInSeconds),
		);

		this.player?.dispatchAction(
			new kmp.player.api.PlayerAction.SeekTo(position),
		);
	}

	goto(index: number, startPositionInSeconds: number) {
		if (
			this.player?.playerState.value.canJumpToTrack(index) &&
			this.player?.playerState.value.canSeek(startPositionInSeconds)
		) {
			this.player?.dispatchAction(
				new kmp.player.api.PlayerAction.JumpToPosition(
					index,
					startPositionInSeconds,
				),
			);
		} else {
			throw new Error('Cannot jump to track at index ' + index);
		}
	}

	setVolume(volume: number) {
		const clampedVolume = Math.max(0, Math.min(1, volume));
		this.player?.dispatchAction(
			new kmp.player.api.PlayerAction.SetVolume(clampedVolume),
		);
	}

	getVolume(): number {
		return this.player?.playerState.value.volume ?? 0;
	}

	setPlaybackSpeed(speed: number) {
		const clampedSpeed = Math.max(0, Math.min(5, speed));
		this.player?.dispatchAction(
			new kmp.player.api.PlayerAction.SetPlaybackSpeed(clampedSpeed),
		);
	}

	getPlaybackSpeed(): number {
		return this.player?.playerState.value.playbackSpeed ?? 1;
	}

	getBufferedPosition(): number {
		return this.player?.progress.value.bufferedPosition ?? 0;
	}

	getCurrentPosition(): number {
		return this.player?.progress.value.currentPosition ?? 0;
	}

	getDuration(): number {
		return this.player?.progress.value.duration ?? 0;
	}

	getPlaybackState(): IDeezerPlaybackState {
		const playbackState: IDeezerPlaybackState = {
			isPaused: () => () =>
				this.player?.playerState.value.playbackState.name ===
				DeezerPlayerStates.IDLE,
			playerState: this.player?.playerState.value.playbackState.name,
			capabilities: {
				canPlay: () =>
					this.player?.playerState.value.capabilities.canPlay ?? false,
				canPause: () =>
					this.player?.playerState.value.capabilities.canPause ?? false,
				canSeek: () =>
					this.player?.playerState.value.capabilities.canSeek ?? false,
				canNext: () =>
					this.player?.playerState.value.capabilities.canNext ?? false,
				canPrevious: () =>
					this.player?.playerState.value.capabilities.canPrevious ?? false,
				canSetPlaybackSpeed: () =>
					this.player?.playerState.value.capabilities.canSetPlaybackSpeed ??
					false,
			},
			isInAudioBreak:
				this.limiter?.permissionsLimiterState.value.isInAudioBreak ?? false,
		};

		return playbackState;
	}

	setAds(hasAds: boolean) {
		if (hasAds) {
			this.limiter?.dispatchAction(
				new kmp.player.permissions.limiter.PermissionsLimiterAction.Start(
					this.user?.id ?? '',
				),
			);
		} else {
			this.limiter?.dispatchAction(
				kmp.player.permissions.limiter.PermissionsLimiterAction.Stop,
			);
		}
	}

	getLimitationState(): IDeezerLimitationState {
		return {
			isSkipLimitReached:
				this.limiter?.permissionsLimiterState.value.isLimitReached ?? false,
		};
	}

	initializeSubscriptions() {
		if (!this.player) return;

		// Subscribe to player state changes
		this.player.playerState.subscribe(
			() => {
				this.notifyStateSubscribers();
				this.notifyPlaybackStateSubscribers();
				this.notifyCurrentMediaChangedSubscribers();
			},
			() => void 0,
		);

		// Subscribe to progress updates
		this.player.progress.subscribe(
			() => {
				this.notifyProgressSubscribers();
			},
			() => void 0,
		);

		// Subscribe to player error events
		this.player.failureEvents.subscribe(
			(error) => {
				this.notifyPlayerErrorSubscribers(error);
			},
			() => void 0,
		);

		// Subscribe to player limitation events
		this.limiter?.permissionsLimiterState.subscribe(
			(state) => {
				this.notifyLimitationSubscribers(state);
			},
			() => void 0,
		);
	}

	notifyStateSubscribers() {
		this.stateListeners.forEach((listener) => listener());
	}

	notifyPlaybackStateSubscribers() {
		this.playbackStateListeners.forEach((listener) =>
			listener(this.getPlaybackState()),
		);
	}

	notifyProgressSubscribers() {
		const progress: IDeezerPlayerProgress = {
			bufferingPosition: this.getBufferedPosition(),
			position: this.getCurrentPosition(),
			duration: this.getDuration(),
			positionPercent: (this.getCurrentPosition() / this.getDuration()) * 100,
			bufferingPositionPercent:
				(this.getBufferedPosition() / this.getDuration()) * 100,
		};

		this.playbackProgressListeners.forEach((listener) => listener(progress));
	}

	notifyLimitationSubscribers(
		state: kmp.player.permissions.limiter.PermissionsLimiterState,
	): void {
		this.playerLimitationListeners.forEach((listener) => {
			if (state.isLimitReached) {
				listener.onSkipLimitReached();
			}
		});
	}

	notifyPlayerErrorSubscribers(error: IDeezerPlayerFailure) {
		this.playerErrorListeners.forEach((listener) => listener(error));
	}

	notifyCurrentMediaChangedSubscribers() {
		const currentQueueItem = this.queueList.getCurrentMedia();
		const currentMedia: IDeezerCurrentMedia = {
			media: currentQueueItem ? currentQueueItem.playable : null,
		};
		this.currentMediaChangedListeners.forEach((listener) =>
			listener(currentMedia),
		);
	}

	subscribeState(listener: () => void): void {
		this.stateListeners.add(listener);
	}

	unsubscribeState(): void {
		this.stateListeners.clear();
	}

	subscribeOnPlaybackStateChanged(
		listener: (state: IDeezerPlaybackState) => void,
	): void {
		this.playbackStateListeners.add(listener);
	}

	unsubscribeOnPlaybackStateChanged(): void {
		this.playbackStateListeners.clear();
	}

	subscribeOnPlaybackProgress(
		listener: (progress: IDeezerPlayerProgress) => void,
	): void {
		this.playbackProgressListeners.add(listener);
	}

	unsubscribeOnPlaybackProgress(): void {
		this.playbackProgressListeners.clear();
	}

	subscribeOnPlayerLimitation(listener: IDeezerPlayerLimitationListener): void {
		this.playerLimitationListeners.add(listener);
	}

	unsubscribeOnPlayerLimitation(): void {
		this.playerLimitationListeners.clear();
	}

	subscribeOnPlayerError(
		listener: (error: IDeezerPlayerFailure) => void,
	): void {
		this.playerErrorListeners.add(listener);
	}

	unsubscribeOnPlayerError(
		listener: (error: IDeezerPlayerFailure) => void,
	): void {
		this.playerErrorListeners.delete(listener);
	}

	subscribeOnCurrentMediaChanged(
		listener: (media: IDeezerCurrentMedia) => void,
	): void {
		this.currentMediaChangedListeners.add(listener);
	}

	unsubscribeOnCurrentMediaChanged(): void {
		this.currentMediaChangedListeners.clear();
	}
}
