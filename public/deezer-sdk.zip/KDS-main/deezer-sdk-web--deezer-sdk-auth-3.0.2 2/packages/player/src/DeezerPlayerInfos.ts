import {KMPP as kmp} from '@deezer/deezer-kmp-player';
import {IDeezerPlaybackState} from './DeezerPlayer';

export interface IDeezerPlayerProgress {
	positionPercent: number;
	position: number;
	duration: number;
	bufferingPosition: number;
	bufferingPositionPercent: number;
}

export interface IDeezerPlayerFailure {
	playableIndex: number;
	playable: kmp.player.models.Playable;
	failure: kmp.player.models.errors.PlayerFailure;
}

export interface IDeezerCurrentMedia {
	media: kmp.player.models.Playable | null;
}

export interface IDeezerPlayerLimitation {
	isLimited: boolean;
	reason?: string;
}

export interface IDeezerLimitationState {
	isSkipLimitReached: boolean;
}

export enum DeezerPlayerCommand {
	PLAY = 'PLAY',
	SEEK = 'SEEK',
	PREVIOUS = 'PREVIOUS',
	NEXT = 'NEXT',
	GOTO = 'GOTO',
	SHUFFLE = 'SHUFFLE',
	REPEAT_MODE = 'REPEAT_MODE',
}

export interface IDeezerPlayerLimitationListener {
	onConcurrentStreamLimitReached(): void;
	onSkipLimitReached(): void;
	onPlayerActionIgnored(command: DeezerPlayerCommand): void;
}

export interface IDeezerPlayerInfos {
	subscribeOnPlaybackProgress(
		listener: (progress: IDeezerPlayerProgress) => void,
	): void;
	unsubscribeOnPlaybackProgress(listener: () => void): void;
	subscribeOnPlaybackStateChanged(
		listener: (state: IDeezerPlaybackState) => void,
	): void;
	unsubscribeOnPlaybackStateChanged(listener: () => void): void;
	subscribeOnPlayerError(listener: (error: IDeezerPlayerFailure) => void): void;
	unsubscribeOnPlayerError(listener: () => void): void;
	subscribeOnPlayerLimitation(listener: IDeezerPlayerLimitationListener): void;
	unsubscribeOnPlayerLimitation(): void;
	subscribeOnCurrentMediaChanged(
		listener: (media: IDeezerCurrentMedia) => void,
	): void;
	unsubscribeOnCurrentMediaChanged(): void;
	getBufferedPosition(): number;
	getCurrentPosition(): number;
	getDuration(): number;
	getPlaybackState(): IDeezerPlaybackState;
	getLimitationState(): IDeezerLimitationState;
}
