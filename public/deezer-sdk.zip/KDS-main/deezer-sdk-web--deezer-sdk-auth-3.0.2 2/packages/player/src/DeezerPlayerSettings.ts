import {KMPP as kmp, SupportedEncodings} from '@deezer/deezer-kmp-player';

export const DeezerAudioQualities = {
	FLAC: 'FLAC',
	MP3_320: 'MP3_320',
	MP3_128: 'MP3_128',
	UNKNOWN: 'UNKNOWN',
} as const;

export type DeezerAudioQuality =
	| typeof DeezerAudioQualities[keyof typeof DeezerAudioQualities]
	| undefined;

export class DeezerPlayerSettings {
	private player: kmp.player.api.PlayerApi;
	private setEncoding: (encoding: NonNullable<SupportedEncodings>) => void;

	constructor(
		player: kmp.player.api.PlayerApi,
		setEncoding: (encoding: NonNullable<SupportedEncodings>) => void,
	) {
		this.player = player;
		this.setEncoding = setEncoding;
	}

	setVolumeNormalisationEnabled(enabled: boolean) {
		if (enabled) {
			this.player?.dispatchAction(
				new kmp.player.api.PlayerAction.SetVolumeNormalization(
					kmp.player.models.VolumeNormalization.Enabled.withDefaultGain(),
				),
			);
		} else {
			this.player?.dispatchAction(
				new kmp.player.api.PlayerAction.SetVolumeNormalization(
					kmp.player.models.VolumeNormalization.Disabled,
				),
			);
		}
	}

	isVolumeNormalisationEnabled(): boolean {
		return (
			this.player?.playerState.value.volumeNormalization !==
			kmp.player.models.VolumeNormalization.Disabled
		);
	}

	getVolumeNormalisationTargetGain(): number {
		const volumeNorm = this.player?.playerState.value.volumeNormalization;
		if (volumeNorm instanceof kmp.player.models.VolumeNormalization.Enabled) {
			return volumeNorm.targetGain;
		}
		return 0;
	}

	setVolumeNormalisationTargetGain(gain: number) {
		const clampedGain = Math.max(-20, Math.min(20, gain));
		this.player?.dispatchAction(
			new kmp.player.api.PlayerAction.SetVolumeNormalization(
				new kmp.player.models.VolumeNormalization.Enabled(clampedGain),
			),
		);
	}

	get audioQuality(): DeezerAudioQuality {
		const encoding = this.player?.playerState.value.playbackMedia?.encoding;
		if (!encoding) return DeezerAudioQualities.UNKNOWN;

		switch (encoding.name) {
			case 'MP3_128':
				return DeezerAudioQualities.MP3_128;
			case 'MP3_320':
				return DeezerAudioQualities.MP3_320;
			case 'FLAC':
				return DeezerAudioQualities.FLAC;
			default:
				return DeezerAudioQualities.UNKNOWN;
		}
	}

	updateAudioQuality(quality: DeezerAudioQuality): DeezerAudioQuality {
		switch (quality) {
			case DeezerAudioQualities.MP3_128:
				this.setEncoding(kmp.player.models.Encoding.MP3_128);
				break;
			case DeezerAudioQualities.MP3_320:
				this.setEncoding(kmp.player.models.Encoding.MP3_320);
				break;
			case DeezerAudioQualities.FLAC:
				this.setEncoding(kmp.player.models.Encoding.FLAC);
				break;
			default:
				return DeezerAudioQualities.UNKNOWN;
		}

		return quality;
	}
}
