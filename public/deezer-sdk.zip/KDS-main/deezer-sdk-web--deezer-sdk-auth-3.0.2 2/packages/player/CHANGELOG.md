# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [8.7.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@8.7.0...@deezer/sdk-player@8.7.1) (2025-07-24)


### Bug Fixes

* **cicd:** put back config in gitignore to allow canary publish ([d83022c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d83022c10a9bcf008e53dd3d7d34263de86f6de3))
* **config:** remove config file ([7eb754c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/7eb754cb4e4f709efd790c82b2839f33f8842a79))
* update Deezer API endpoint to use pipe.deezer.com ([219ad86](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/219ad868192227d6999168e96455d659cb7f6ee8)), closes [#288](https://github.deezerdev.com/Partnership/deezer-sdk-web/issues/288)





# [8.7.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@8.6.0...@deezer/sdk-player@8.7.0) (2025-03-18)


### Features

* add canEdit method to DeezerQueueList ([eab4d24](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/eab4d24157646c2512d7749b20d0a4f8dff95241))





# [8.6.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@8.5.0...@deezer/sdk-player@8.6.0) (2025-03-11)


### Features

* add current media changed event support ([8e91185](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8e9118587a088b1f60dab3a23d07d51d264f565b))





# [8.5.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@8.4.0...@deezer/sdk-player@8.5.0) (2025-03-06)


### Features

* version bump only ([e244e53](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e244e5318b581fb64a01c13ae80d70376d3b227f))
* version bump only ([e8c709d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e8c709dc3b7f48465cfe359d829342e807df2b06))





# [8.4.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@8.3.1...@deezer/sdk-player@8.4.0) (2025-02-26)


### Features

* add ads media renderer to DeezerPlayer configuration ([8de3b80](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8de3b80e04ae60b501a4c81f847f75387177f111))
* add player limitation handling and related interfaces ([bffe299](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/bffe299f1a822411dd44a89396539e4580b6cd11))
* add player limitation handling and tracking ([dd95105](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/dd9510591ce35cc8027af7bdbf543ee637346337))
* enable ads in Deezer player initialization ([9b5ac56](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9b5ac5691fa90a67efbe3b8412ba9b8d91702057))
* export additional ads media renderer types ([fbd0826](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/fbd082600f234d4616de57775bf97a7a280614ba))





## [8.3.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@8.3.0...@deezer/sdk-player@8.3.1) (2025-02-05)

**Note:** Version bump only for package @deezer/sdk-player





# [8.3.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@8.2.0...@deezer/sdk-player@8.3.0) (2025-01-31)


### Bug Fixes

* add log ([365b0f2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/365b0f2d64708a5fe41df06005f0bf9f3990f611))
* add log ([54c2139](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/54c2139deb171b5eb8ce809f425ded9f303d1ee3))
* add log ([80d5f62](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/80d5f62321e42c3b69f190cef62602a9284482ff))
* add missing export ([9036580](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/90365805493b93ad577679ef089fe4dcbd114e84))
* build types ([225266e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/225266ea726ad7250315200249f9f5834d83f20d))
* clean ([29fe531](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/29fe531f5b9d777ad67842a7bbc7d4dbd4a9a31a))
* copyToMPList ([ed078fa](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ed078fab605ceafaa950e419e3f02ab25b235fb7))
* correct path for XPlayer type definition export ([7f18012](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/7f180129fe194967d15865ea02e1156efdecf4dc))
* debug mode ([b4370fd](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b4370fd093fa0d70bb2e9fc4ad62ac41cde6c37e))
* default config ([e07c425](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e07c4250f3484d4ae5af7565fbbaf10ec9132efa))
* default quality ([279d915](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/279d915a737eefedf469f61d1140eba89b2f3c59))
* export missing stuff ([6189260](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/61892607ceabc5b8b9bd0a59d615cc9fea0ac7dc))
* export missing stuff ([cd50433](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/cd50433d83e2898661b4192b8e4210bd5c562d02))
* optional playables ([72d7c59](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/72d7c59f5e2470320ea5d5a65de6c960c0753f8e))
* prop order ([0832ef3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0832ef310f84b2a0d9b3a5a1d890ad26a29810f2))
* remove constructor ([e19787f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e19787f60638b4512c1b84d42f7205c24c2e4db9))
* set encoding ([c98880e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c98880e27a14f214885cf207c9dc0c9431c7160d))
* setInfiniteQueue ([056a526](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/056a526ac1d465c190eea189e669b6654c39ecc8))
* spacing ([bb7f515](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/bb7f51547a86acf1ca0987db4ccb5edb9da4beff))
* types extraction ([2e506f5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2e506f531c46f38dec68433ee4709e42dfd86691))
* update XPlayer type definition export path ([9b43303](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9b43303a084d57652d3953ba422b2770dba923d4))


### Features

* add batchProvider in player config ([0566296](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/05662968aa84520477fec0773e5b658971afe28b))
* add default config ([c509141](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c509141f6934070d6c77c219903d787353a8ca1a))
* add setInfiniteQueue ([9a1982c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9a1982c96e6f44adcd13492a04a97cedee84fe87))
* expose batch provider ([cdee55d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/cdee55d1aa21f8d9c9c5b813d8df695962d2fb5e))
* implement audio quality setting ([3de82ff](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3de82ff195610dc016c8d135bec765997c693365))





# [8.2.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@8.1.0...@deezer/sdk-player@8.2.0) (2024-12-18)


### Bug Fixes

* duplicated init ([5e71e95](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5e71e955999503e9a046172d9add79d4cc0a06c1))


### Features

* implement volume normalization ([ce12d88](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ce12d88aa3cdfbbdd9cb41526dca6b6d6d00739b))





# [8.1.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.15.0...@deezer/sdk-player@8.1.0) (2024-12-13)


### Bug Fixes

* add abstraction layer ([e272354](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e272354b5da087ef7ffcbdee2edc902276fba210))
* add check on goto ([b9b2681](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b9b2681a31e95e29ed9784cdf3ee2b8d6fa3ed2b))
* add missing export ([1999a9e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1999a9e4cac75ed4d396add040d091f9df8400fe))
* add player state type ([fccfc1e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/fccfc1efd195815c38e3cfe1f47bee37c683b58c))
* clean up ([a8054f1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a8054f1cc1ac40265bd0f8ac1a448b1e08ec88b9))
* duplicate code ([eb4cf72](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/eb4cf72bfd7c7d4b58ad182bcd626aef00815d3e))
* export repeat modes ([158763a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/158763a0a51613dba73fc8d1bdd55d17906dcf35))
* export repeat modes ([700bceb](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/700bceb6ec92fce2aae31d319b738f78939e2db9))
* exports ([0554e6b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0554e6bb5e8cc987fed0c7b5e36b978cc297fbf2))
* increase max playback speed ([0aec34f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0aec34f70b31dcb5be4c08ca42aa975752e119cb))
* naming ([139b57d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/139b57d76e5fed0105fb0d8f2af98bbf40270501))
* percentages ([2e1a013](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2e1a013e2f0835837704cc2683e41f4f54a0883d))
* player states definition ([781082a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/781082aa894c19f58630d572bc8ea4c98148f1eb))
* prevent seeking out of range ([0b0e5d6](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0b0e5d634591be87ddd43e2cfc438b07d375f70c))
* refactor to use interfaces ([bdda3a8](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/bdda3a84f3cc73fb23b6eb3fb0906d7770da10d9))
* remove minification ([143175b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/143175bee87306f0cc0fab931720d7c98c180b1f))
* remove unused file ([e7d7421](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e7d7421795eaad155558efe7771815873cac9888))
* subscriptions ([77ebf29](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/77ebf29d0cf1c42febbc3b27fd9b602bf4913162))


### Features

* add goto method ([82a576e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/82a576e764ac2973ff7cc28381d02410cb83f6b1))
* add method to subscribe to the player state ([e126db3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e126db3b7e076cbb843f06b30e40646d386a807a))
* add playback progress ([f5570a7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f5570a7924b5d8e96b8c6250a20fdaf39fb4aec0))
* add playback speed setter and getter ([4512967](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/45129675d0dc28d38fbc6b00d72369644cb79395))
* add playback state management ([6e1f5ec](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6e1f5ecad3a4b34b47970c8649c8003c93e6d4e5))
* add queue event listeners ([6c88cd6](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6c88cd664f678d506456d1adfbe0820b5183342b))
* add queue management methods ([7da56b4](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/7da56b414237fbf1ac0d87eb8c7f67c0ff17d06c))
* add repeat mode getter and setter ([1eaafb7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1eaafb79f9164e394b9d3ec694a6a22ad09daa72))
* add shuffle ([b3a12f3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b3a12f353da5b30fffb70261d29a18bd69d8a754))
* add volume setter and getter ([cd63b49](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/cd63b49c5967a5522d95a09f5d7dd8cc276303ea))
* export progress class ([632dcea](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/632dcea75f5abe8a854c5a391b841cbcc8978a23))
* implement queue capabilities class ([9457164](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/94571647286e77a89ed4730e842482b9c43eeaed))





# [7.15.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.14.2...@deezer/sdk-player@7.15.0) (2024-03-13)


### Features

* add custom url provider ([50f35be](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/50f35be7b71abfcbaab59fd56dc1897035effa5f))





## [7.14.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.14.1...@deezer/sdk-player@7.14.2) (2024-02-20)


### Bug Fixes

* remove time to play log ([6024f75](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6024f7536f860b0eb155bb98d57838e406f0b14d))





## [7.14.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.14.0...@deezer/sdk-player@7.14.1) (2024-02-02)


### Bug Fixes

* log type ([b8b1c54](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b8b1c541d9ecec6aaf7329919337682815bb66c7))
* togglePlay behavior and autoskip ([247ef91](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/247ef91e3e9ea205792ce1d0fd75a1a2534cca01))





# [7.14.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.13.4...@deezer/sdk-player@7.14.0) (2023-10-05)


### Features

* rename internal flow config method ([0b55dfe](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0b55dfe506b0b0c4f78a7f3de3b200692cd63a2b))





## [7.13.4](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.13.3...@deezer/sdk-player@7.13.4) (2023-09-21)

**Note:** Version bump only for package @deezer/sdk-player





## [7.13.3](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.13.2...@deezer/sdk-player@7.13.3) (2023-09-15)


### Bug Fixes

* natural skip unallowed tracks ([b4372c7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b4372c7928568b23db077b8a80673f67f59724af))





## [7.13.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.13.1...@deezer/sdk-player@7.13.2) (2023-08-29)

**Note:** Version bump only for package @deezer/sdk-player





## [7.13.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.13.0...@deezer/sdk-player@7.13.1) (2023-08-18)


### Bug Fixes

* handle case were previous track is unplayable ([b7b5553](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b7b55537b4e49942ac9a3e14699f123d3290b5d6))





# [7.13.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.12.0...@deezer/sdk-player@7.13.0) (2023-07-21)


### Bug Fixes

* autoskip ([3e5f7d7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3e5f7d741ddf4e879b7d6eef6d1c9024a96f281e))
* autoskip ([1bc4870](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1bc4870557f368257302cebcbed5f49cf98c65c8))
* autoskip ([4504e27](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4504e2703ae0bbdc429fadcd0474d17eeb4b34eb))
* autoskip ([9327852](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/93278525713d4af8d269d34234914c344fcabebf))
* autoskip ([c70a2e1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c70a2e1432bea75823ef8fc0b1454ba9452c7eb4))
* autoskip ([f2ea836](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f2ea83619b9aac511e270c2820ba13560eaaa8e3))
* autoskip ([9ba89a3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9ba89a39ecc0dabb921808071aee06a6a9577e9e))
* autoskip ([0add907](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0add9075c2f7cb9aa2ecdff2d12b4b2024b750b3))
* autoskip ([5932a5d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5932a5dc073c7b0f8357920600f2446fceb2751f))
* autoskip ([6fb4a99](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6fb4a994e1d3c30d4f4c6b0dc6efeea94e8096df))
* autoskip ([4a26efd](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4a26efdd79e9c0b8b5c77ae1bbd79374c41fbbf9))
* autoskip ([fdeb04b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/fdeb04bb3d5f0b7f1263c64f2b7f10985975b07e))
* autoskip ([04bd72c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/04bd72cf0fc1cdf3968fce895db920e0c3bc98be))
* autoskip ([c9d00a3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c9d00a31f91176db17733cd1c90dd0990a0dfc64))
* autoskip ([177aa5a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/177aa5a1e6895c1f227bfce68eb9b304d92a3032))
* autoskip ([b4d1c7f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b4d1c7f3c337b54b47bfd23069e001400ea8567d))
* autoskip ([4c144e5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4c144e51e80ffa1da13451a2c6bfe2255669b7a6))
* autoskip ([dd05aa4](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/dd05aa4da2b629eb0b58b7c0e38292cb26d64c97))
* autoskip ([369168a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/369168ae4e6d1ff7d9251a47ba080b6cce57e03d))
* autoskip ([0437dcf](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0437dcfd5245870d5e20d8f3a46838139dc9b6cb))
* autoskip ([1ae85c9](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1ae85c95fe94e712c00baaa9727dd66d44e45974))
* cleaning ([1449c44](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1449c440c3ef4229f84fa03d871b05d88d542655))
* handle NotAllowedError on Safari ([ac8c0af](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ac8c0af41d66a5db7f099e4fa9db4e6bef47b8ed))
* remove event listener ([2fc331e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2fc331e21a8f980dcafba076357b98b30f6745dc))
* remove log ([6c35028](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6c350287ff63eebf1366aa7629fc41248a800de7))
* remove unplayable track ([e2e1169](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e2e1169e344b5c595f12b98655a713007a5b709b))


### Features

* **queue:** add reorder method ([8fa7830](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8fa7830701813fe701e7162e2f1df771ba57f8cc))





# [7.12.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.11.0...@deezer/sdk-player@7.12.0) (2023-06-02)


### Features

* add raw tracks queries and autoskip unplayable tracks ([2746324](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/274632409d2331f7a4a9658d275acddab50ba93c))





# [7.11.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.10.0...@deezer/sdk-player@7.11.0) (2023-05-26)


### Bug Fixes

* **player:** fix playback state when calling seek while paused ([7dce2cd](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/7dce2cdfe51d5c68d602e87cf7ee261676fedefe))


### Features

* better condition ([9521594](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9521594e489d38d17ce30ed143ff91f5fef31413))
* prevent initialization when user id is missing ([f11e325](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f11e3257b9f1271f892c50f90bb64d1bc6d15dfd))





# [7.10.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.9.2...@deezer/sdk-player@7.10.0) (2023-04-13)


### Features

* export Encoding_FLAC ([9bbe20e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9bbe20eb6d8ea75b9578e72da284b0f3eba050c3))





## [7.9.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.9.1...@deezer/sdk-player@7.9.2) (2023-04-06)


### Bug Fixes

* media started event ([99e6e03](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/99e6e030b9769f5f22e17634becd0ea859cc68c3))





## [7.9.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.9.0...@deezer/sdk-player@7.9.1) (2023-03-30)


### Bug Fixes

* add @deezer/graphql-client to api-extractor ([5017f3c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5017f3c089a52967c6ff7519ec52fde6af41be2b))
* reexport types ([7218441](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/7218441ec1d6b9771c5f61f469d6297c30216888))
* use types from @apollo/client/core ([c4c282e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c4c282e339e1c14f903ef274cf0b4360bca84326))





# [7.9.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.8.1...@deezer/sdk-player@7.9.0) (2023-03-30)


### Bug Fixes

* add log ([274542e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/274542e9ac42410a9e30f7569db5c48a9d611c7f))
* add log ([7c4d2c0](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/7c4d2c01ad9530cbfe13f21216060797e8a8b9b6))
* add logs ([2a42cce](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2a42ccea509e9a26aaf60a6ca111c7ab4f88ef2b))
* add reset ([6ee3a44](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6ee3a44975a45ea2165c939f15ad1e65cde3f5d1))
* condition ([11af165](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/11af1652bf5b229c12fe2ef370a902f376105f6b))
* remove apollo ([7f05be2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/7f05be2dbf7cc57dac566995b10092d829ef00fa))
* remove event ([e0e0816](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e0e081684a6ce2723a33d987c32f306a4c15e39f))
* remove flacky test ([37df6f3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/37df6f3005e27cfd79b778c30798a15fc4acb7c5))
* remove hooks ([ae28efd](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ae28efde2dbd00a8cd6a016a8afc200369b5f738))
* remove trigger ([b2ec29d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b2ec29d4b6957425b992d9f886be88c2215cb2ce))
* subscribe method typing ([e2dccae](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e2dccae3ca50b6674363cac10c1dbd8ac0cc250a))


### Features

* add media started event ([b71f1d5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b71f1d5b6601445ad0aee6c3410ee83b7f0b9f03))
* make getPlaybackState and getPlaybackProgress methods public ([ac4930f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ac4930f38c3d087629603e02301716ed38d3dc8a))
* use deezerlib graphql client ([8a4650d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8a4650daadbcdccdecd8cff5463be3558bfda688))





## [7.8.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.8.0...@deezer/sdk-player@7.8.1) (2023-03-15)


### Bug Fixes

* remove trackIndex from playFlowMood ([c22fd47](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c22fd47bfb9c48dca7d4fc98c5a8da357f3741d7))





# [7.8.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.7.0...@deezer/sdk-player@7.8.0) (2023-03-15)


### Bug Fixes

* duplicate value in enum ([8b342b5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8b342b51315f3d9e4ad36707b09439db4162e797))


### Features

* add flow mood context ([db033bb](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/db033bb7b5f6223b6a697ca39395e20f38caa30b))
* add playFlowMood method ([5785d74](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5785d74afdd484fcd79cb3ef9e99b292e11d00a7))





# [7.7.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.6.1...@deezer/sdk-player@7.7.0) (2023-03-01)


### Bug Fixes

* fragments path ([97fa233](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/97fa233d1165adf8122fff3a947e3c110b732092))
* use correct query document ([b568f95](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b568f95ab345fb847198a20b19eee9d00adb5ad7))


### Features

* add artist top tracks query and playArtist method ([0d02784](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0d02784b1703d7e3f416e99e5627e206e9d4285d))
* add internal queries ([9452ee3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9452ee344e9206fd1c220c1be87d40d4b9c78536))





## [7.6.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.6.0...@deezer/sdk-player@7.6.1) (2023-02-23)


### Bug Fixes

* make getToken and invalidateCurrentToken optional ([fcf751a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/fcf751ab8d971e3f28dd338da88e740279e74a82))
* player state after seek ([f990b19](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f990b19c5d39658d4ddefa002dfcaa3f818028e1))
* typo ([44a5cb3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/44a5cb3a7df3279fda10a87a299180c338478ce4))





# [7.6.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.5.0...@deezer/sdk-player@7.6.0) (2023-02-20)


### Bug Fixes

* add missing dependency ([9a99af7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9a99af7ca325be3075cc2e9f766aa897534bb94c))
* prettier ([3601b1a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3601b1a879efaee4a2933f9ef943bdc6e306f457))
* remove definitions files ([9478956](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9478956c5d13507d7a78f805fcaf4170ffa2a6b8))
* remove source maps from production build ([caba735](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/caba735391ec8300ff1b9ac93412af31150e1f4d))
* remove useless file ([65e962f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/65e962f3f348d8636fa3e738bda6234f5ade4c0f))
* typings ([07b30eb](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/07b30ebfb51aa67da537df30c68b1409fca30119))
* typo ([aebc4fb](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/aebc4fb3e4120e87aae5fe50d07061a32add6f29))


### Features

* add album gql queries ([0082fa5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0082fa5c4a4e69c612ab77ff9841083cd1534cd5))
* add playlist queries ([95d5bf5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/95d5bf5c37976beea471ad7050561de3c4046282))
* add query and playAlbum methods ([99e481c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/99e481cf4152996aad34c1a72ea5f24846123eea))
* **player:** add playPlaylist ([40aece4](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/40aece4d711c9af5c91ea2e4959052b89ede08e1))





# [7.5.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.4.0...@deezer/sdk-player@7.5.0) (2023-01-27)


### Bug Fixes

* **player:** make createClient private ([e188551](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e188551b33a3ba337758421aaf1db47cca0e15d8))


### Features

* **player:** add Apollo GraphQL client ([cbff160](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/cbff16021cec842bb7c584d3f1b6e4287eb35a24))





# [7.4.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.3.4...@deezer/sdk-player@7.4.0) (2023-01-10)


### Bug Fixes

* **kmpp:** add log ([9145c77](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9145c7708981e7a091998a3544e7b246491b8f2c))
* **kmpp:** disable minification ([8df8cf2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8df8cf25646aad4e1089b337085cd367250600ab))
* **kmpp:** switch webpack to development config ([9af2796](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9af2796bc1457dde30054e9f5a4c8bb04eaadf85))
* **player:** fix unit test ([71ec8bf](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/71ec8bf3f88bccc8b41ef215bd0d9f0dfb9ef9f4))
* typing ([9a137f4](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9a137f43f6c8e8e6bdd3c3e58b990cdf6d722003))


### Features

* add jumpToTrack and canJumpToTrack ([5ddabf6](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5ddabf6c7fb42cc30ac479b927ddd9d41b663df6))
* return boolean for canJumpToTrack ([fd78f21](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/fd78f2160ee0a239dc4bad18c6cfaeda0eb64291))





## [7.3.4](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.3.3...@deezer/sdk-player@7.3.4) (2022-10-25)


### Bug Fixes

* **deps:** update dependency uuid to v9 ([c37ff48](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c37ff48048ade992fdf93541a0ea7a37ad7fdf41))
* **player:** fix loading state when seeking ([bc35169](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/bc35169e64c56e3ab0c6c96ed0147f0667576c9a))





## [7.3.3](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.3.2...@deezer/sdk-player@7.3.3) (2022-10-13)

**Note:** Version bump only for package @deezer/sdk-player





## [7.3.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.3.1...@deezer/sdk-player@7.3.2) (2022-09-27)


### Bug Fixes

* add measures to localStorage ([a28ad96](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a28ad968b1c9aa14cf47248bf93c663e74608e84))





## [7.3.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.3.0...@deezer/sdk-player@7.3.1) (2022-09-27)


### Bug Fixes

* clear measures ([baff98b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/baff98b6611246b1647e58fe6931612f92fb03a4))





# [7.3.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.2.2...@deezer/sdk-player@7.3.0) (2022-09-27)


### Bug Fixes

* add progress to measure ([e552c65](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e552c6559a5a2533c1f41d25fe7275bb50189137))
* condition performance measurement ([54f88a7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/54f88a76478ab76453a7671fff966f948b9dbd66))
* fix measure ([9c2d2d0](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9c2d2d02a237dbf3d39bda6ede32783a71e66f62))
* fix measure ([ec3668c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ec3668cb17eeb87e9b7c6fc5bf7c713dfb812800))
* fix measurements data ([d43d1dc](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d43d1dc286b784ab7d0204eecdabc3e493ae9a7c))
* fix measures ([f45325b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f45325b1d20b384a79366b63ed18915643da0ab4))
* fix measures ([3288d6f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3288d6f2dc6bfe1f2015d7df7b64bbaa28a04569))
* log measures server response ([37c174d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/37c174da44e5b63b0ac050240f7bcef49978d679))
* measure naming ([f936875](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f93687588ea5cb54240066edf036116bd1252252))
* move starting playback marker when position changes from 0 ([dbc4ccf](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/dbc4ccff1f66b56def78d65c7543a447ee3cfada))
* move ttl mark ([dc7f44d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/dc7f44d91e5510abf31207e9be3ebf99650c845d))
* remove some measures ([207a02b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/207a02b5901016f72a36ca4ecf1794462980716e))
* typo ([fcee97b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/fcee97b3d3577bdb3f03a72082a252e8b8a328f1))
* update measure endpoints ([813791a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/813791ab235e1c7f4e1eef3f1b1c42fe00ca8bcc))
* update ngrok url ([9b6cbc1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9b6cbc130edfff6c4335dc9446c7c33453bd07dc))
* update server IP and add trackIndex to measures ([b9a03ce](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b9a03cec70ce5adbe44b726acedaf95664ebce81))


### Features

* add custom measure for first progress ([53e0f66](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/53e0f661540a0882be01894f2313fc3428fb3fa5))
* add new marks ([f491fc1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f491fc1f7cee6d9630abe908dd1dce3b051a6957))
* add time to load measure ([a2af1e2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a2af1e2bc86066a04cfc9aeee8864c2d126791c0))
* **player:** expose sinkLimit ([692e2ee](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/692e2ee6f975b2237d2234478b0de21b4b3009d2))
* send measures to automation server ([7d52c05](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/7d52c0576e3e35d498b8a99ee9bff022ad04995a))
* test server receives http request on sdk init ([b940041](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b940041694a474cc7f775985fe40997d0c713883))
* update server IP with ngrok ([624a895](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/624a895083bf0aa81f46df6914b46fffe21bee59))


### Reverts

* put back original ttp ([073cc39](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/073cc39305f05696a2523355dcb3b234c3cc07fb))





## [7.2.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.2.1...@deezer/sdk-player@7.2.2) (2022-09-22)


### Bug Fixes

* **event:** fix SIP trigger ([179faf3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/179faf30cc132d389a7cb6a2d4c98d63c9ad050b))





## [7.2.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.2.0...@deezer/sdk-player@7.2.1) (2022-09-01)


### Reverts

* Revert "chore(release): publish packages" ([ef1ff28](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ef1ff283fdbbf823d5a6bfc483570293a4aa037b))





# [7.2.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.1.0...@deezer/sdk-player@7.2.0) (2022-08-26)


### Features

* **player:** expose canPrevious method in playbackState ([92b6ba7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/92b6ba7bb94d51bde16caed51d65fe767b8f9cde))





# [7.1.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.0.5...@deezer/sdk-player@7.1.0) (2022-08-22)


### Features

* **player:** handle autoplay ([976074c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/976074c6609ae84a11790ecaa4c18c2bf92abfa5))
* **player:** put back ttp logger ([c40e879](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c40e87958d8a363750c52063ba70a90cf2d49a33))
* **player:** remove mediaProvider ([4db2b5e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4db2b5eada4d0ce1ecd5c2781b155cb2e0238d2d))
* **player:** remove renderer usages ([994b5a5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/994b5a556d01888078f9d407231d9706a96f3906))
* **player:** use isLowPerformance option ([9043aab](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9043aab7b115021be2511096b35b5f68bce3fed3))
* **player:** wait for ready ([acc83ff](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/acc83ffd4a544a4ed7d95e48bf9c7c1c0335ba3b))





## [7.0.5](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.0.4...@deezer/sdk-player@7.0.5) (2022-08-04)


### Bug Fixes

* **streamlogs:** update kmpp and fix streamlogs ([a64576e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a64576ebbd746319232b2ab87ae361bd564a44f0))





## [7.0.4](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.0.3...@deezer/sdk-player@7.0.4) (2022-07-28)

**Note:** Version bump only for package @deezer/sdk-player





## [7.0.3](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.0.2...@deezer/sdk-player@7.0.3) (2022-07-27)


### Bug Fixes

* **player:** unsubscribe SIP when destroying player ([bcbd748](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/bcbd74853a3ffcdb0538892b78ff180cdc799d99))





## [7.0.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.0.1...@deezer/sdk-player@7.0.2) (2022-07-26)


### Bug Fixes

* **player:** fix playback state update ([bafacea](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/bafacea7bad5111fdba703b607efdba01d693259))





## [7.0.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@7.0.0...@deezer/sdk-player@7.0.1) (2022-07-12)


### Bug Fixes

* **player:** fix playback state event trigger ([51dc815](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/51dc81583c0b66c8eeef8550c5d07cd1050cb2a6))





# [7.0.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@6.1.1...@deezer/sdk-player@7.0.0) (2022-07-08)


### Code Refactoring

* **player:** expose XPlayer PlaybackState ([61f021d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/61f021dd6397340903f14b168a2e8c1ebb1bbd93))


### Features

* **player:** add shuffle option to togglePlay ([8eaac3d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8eaac3dc392bc8f208907e8d8856cc6752a922e4))


### BREAKING CHANGES

* **player:** expose XPlayer PlaybackState





## [6.1.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@6.1.0...@deezer/sdk-player@6.1.1) (2022-07-04)


### Bug Fixes

* **ttp:** fix duplicate ttp logs ([f7d02f1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f7d02f1d70e17a051a79084e557c4bd40e158d48))





# [6.1.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@6.0.0...@deezer/sdk-player@6.1.0) (2022-07-01)


### Features

* **player:** add measure ([9e34ed6](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9e34ed6ba810fba062904d527e536d67363000bc))
* **player:** add StartingPlayback marker ([1c4937b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1c4937b410eed2d9d6d0918b6565d52f77b28a9d))
* **player:** add time to play metric and log ([2bf03c8](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2bf03c81309e269a87e61133b9c99b95b9a144e2))





# [6.0.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@5.0.2...@deezer/sdk-player@6.0.0) (2022-06-24)


### Bug Fixes

* **player:** fix indexedDb in Firefox ([fd331a2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/fd331a27d80e93ab94d6e1eb8f7de5314ef54008))


### Code Refactoring

* **player:** use a unique event for queue handling ([0e08524](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0e085245a991d40aa1a2de44f4506f47479b340d))


### Features

* **player:** add encoding option ([ffc2d64](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ffc2d64ec25b66280c19edf3754b6fb2da942882))


### BREAKING CHANGES

* **player:** remove queue changed event in favor of a more explicit and unique queue changed





## [5.0.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@5.0.1...@deezer/sdk-player@5.0.2) (2022-06-10)

**Note:** Version bump only for package @deezer/sdk-player





## [5.0.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@5.0.0...@deezer/sdk-player@5.0.1) (2022-05-30)

**Note:** Version bump only for package @deezer/sdk-player





# [5.0.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@4.0.1...@deezer/sdk-player@5.0.0) (2022-05-18)


### Code Refactoring

* **player:** simplify SDKPlayerOptions ([f32df4f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f32df4ffbc44b0c6fdee4f1347c67e7e92152abd))


### Features

* **player:** upgrade @deezer/deezer-kmp-player to 2.2.0 and @deezer/fetch to 2.0.1 ([ddef34e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ddef34e114f3bfaa99e136991e68794bf0238203))


### BREAKING CHANGES

* **player:** replace gaplessplaybackenabled and streaming SDKPlayer options by a single
islowperformance option





## [4.0.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@4.0.0...@deezer/sdk-player@4.0.1) (2022-05-12)


### Bug Fixes

* **events:** add a queue changed event ([c6a39d7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c6a39d75831275216beddde3082c3ff80c92a9e1))





# [4.0.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@3.0.0...@deezer/sdk-player@4.0.0) (2022-05-04)


### Features

* **player:** add gapless playback option ([936ece9](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/936ece9ad3711504e29990a174ae35663f745186))
* **player:** add volume normalization settings ([d4af2dd](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d4af2dd2d71b6093720638c83e4bf0cc1bea3bf8))


### BREAKING CHANGES

* **player:** replace canUseSameSink and canUseSinkStraightAway options with
gaplessPlaybackEnabled





# [3.0.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@2.5.0...@deezer/sdk-player@3.0.0) (2022-04-28)


### Features

* **CI:** create CI job for external release ([2a21c18](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2a21c18e60a421be4cdc745fec855964b22b7394))
* **player:** add canUseSameSink and canUseSinkStraightAway in constructor ([6986059](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/69860599ad38f23f2b88cb2924d3bad1e19ec312))
* **player:** upgrade @deezer/deezer-kmp-player to 2.1.0 ([8103a02](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8103a02fa1c5052a4f14f4c12b0d7deebda8d523))
* **player:** upgrade @deezer/deezer-kmp-player to 2.1.1 ([4b87791](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4b877912cb7514e8435d764a156bb28264e553ea))


### BREAKING CHANGES

* **player:** SDKPlayerException renamed into SDKPlayerFailure





# [2.5.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.46...@deezer/sdk-player@2.5.0) (2022-04-26)


### Features

* **player:** add prefix to app name ([c5e4fa9](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c5e4fa93a1f35e5245848951c9a3903e5df72cad))





# [1.0.0-beta.46](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.45...@deezer/sdk-player@1.0.0-beta.46) (2022-04-21)


### Features

* **player:** add artist context type ([c5afe85](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c5afe8563d5799d29b5623c75337e95454dc1cff))
* **player:** add new context types ([672e40e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/672e40ebf7fcc144066d6289577dff9558811be2))
* **queue:** add addAtPosition method ([8202b74](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8202b7478b4b038e1359aa4007c59a86b61bdf1c))





# [1.0.0-beta.45](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.44...@deezer/sdk-player@1.0.0-beta.45) (2022-04-12)


### Bug Fixes

* **contexts:** allow any context type ([329b6fc](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/329b6fca05ed52d619d5e5d1bc8bb04cdbdf1372))





# [1.0.0-beta.44](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.43...@deezer/sdk-player@1.0.0-beta.44) (2022-04-08)


### Bug Fixes

* **contexts:** fix enum typo ([4080a3b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4080a3b24732de8e04cc9c5d5096b0d5d71f5344))





# [1.0.0-beta.43](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.42...@deezer/sdk-player@1.0.0-beta.43) (2022-04-07)


### Bug Fixes

* **types:** fix PlayerException_2 type issue ([2f6cd44](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2f6cd44ed0e003671260cafd563cb01641c9bc01))


### Features

* **player:** upgrade @deezer/deezer-kmp-player to 1.4.4 ([c76fc1d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c76fc1da8aa0c18e388ce2833efe21f0f57eecd1))
* **player:** upgrade @deezer/deezer-kmp-player to 1.4.5 ([9a297e3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9a297e3a2ee8437e2bf27abc2da19bbce8bf2ed0))
* **player:** upgrade @deezer/deezer-kmp-player to 1.4.5-alpha.2 ([63b08bb](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/63b08bb4272108fcabf13c9a13115c9866b0026c))
* **player:** upgrade @deezer/deezer-kmp-player to 1.4.5-alpha.2+12eb9153 ([f743f31](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f743f31c211e63324dc480e0648ffa714e83446f))





# [1.0.0-beta.42](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.41...@deezer/sdk-player@1.0.0-beta.42) (2022-04-01)


### Bug Fixes

* **player:** remove graphql client ([17e5786](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/17e5786c51faf1e3841d73f34f3ec3436dca21aa))





# [1.0.0-beta.41](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.40...@deezer/sdk-player@1.0.0-beta.41) (2022-04-01)


### Bug Fixes

* **queue:** fix queue duplication ([dbbba98](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/dbbba98cdbc82b9aba256441ae6e18171c3aa949))





# [1.0.0-beta.40](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.39...@deezer/sdk-player@1.0.0-beta.40) (2022-03-31)


### Bug Fixes

* **types:** fix missing type export and dependencies ([ae3aaa4](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ae3aaa43da49d7a8caa4d22ab3ffe17bfc59684a))
* **types:** specify SDKPlayer subscribe method's callback type ([45201a2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/45201a22fe74ab7c57973a7f761b86151e6406f2))


### Features

* **player:** update @deezer/deezer-kmp-player to 1.4.2 ([c101f91](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c101f91c03d4638252d33d54f8ab31d936d6c153))





# [1.0.0-beta.39](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.38...@deezer/sdk-player@1.0.0-beta.39) (2022-03-30)


### Bug Fixes

* **player:** fix set queue ([3b2ecdf](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3b2ecdf5586bf2270cf7aff3f523bc52b845e222))
* **scripts:** fix watch scripts ([2318cd2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2318cd28dcbe13e7cb6628cf550ef7ac7a1e6c0d))
* **watch:** add watch build inside packages ([f9db790](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f9db7900d48ecf461d64123871ee1542da744401))





# [1.0.0-beta.38](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.37...@deezer/sdk-player@1.0.0-beta.38) (2022-03-22)


### Bug Fixes

* **graphql:** fix graphql version ([0004f23](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0004f2301bc66491f91d2a5b5494ecb0339fe38c))
* **graphql:** remove custom deezer graphql client for apollo ([d4a3797](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d4a3797ec709867f7f44920398dc15d96ff45896))
* **lint:** fix lint issues ([4badae1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4badae10c21ee43b54bc240eb2e6d3854f9201d7))


### Features

* **graphql:** add config to .gitignore ([3f43431](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3f43431a8960c4a4f00d594ad5ff160d8f177b86))
* **graphql:** add graphql client ([575953b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/575953bc73e90651428d0b2163371678aea8a65a))
* **graphql:** add graphql client locale as sdk constructor param ([a7a0de0](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a7a0de0629174ef432fb124039cb3d08ccdcbb49))
* **graphql:** fix dependencies issues ([6931dc6](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6931dc6f2251b06e9f89deaacb2a86c5e7d1a230))
* **graphql:** fix repository init ([e7861d0](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e7861d005626cde47685cfb02d59130dc175fa1b))
* **graphql:** move graphql uri and auth host to config ([739c5fb](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/739c5fbbf19be3cc5513da96edef738d92975034))
* **graphql:** remove config ([470fc38](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/470fc382171aea17a30c2361c8cf696130830f50))
* **graphql:** remove hooks from graphql codegen files ([5a21673](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5a2167395fd049ef7dece2aba99247a9765c2df5))
* **player:** add playbackSpeed ([0c35a09](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0c35a09551d1fe3eda006f92a0dfbbfcf7a8ae9a))
* **player:** update @deezer/deezer-kmp-player to 0.22.2 ([8ba9da3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8ba9da300ea8a980da461afbd283a9abd4f363dd))





# [1.0.0-beta.37](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.36...@deezer/sdk-player@1.0.0-beta.37) (2022-03-07)


### Bug Fixes

* **playback:** add condition on safari workaround ([4d82cea](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4d82cea307e302155faee8952e94daf1af22bd2d))
* **player:** fix SDKQueue workaround ([5d0e786](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5d0e786f57435392467097fc02f63107b25d8535))


### Features

* **playback:** better condition ([2d15e1b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2d15e1be1425170dda2889be019a375b67aa6609))
* **playback:** disable autoplay after playback has started ([f773752](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f773752dea95b17f8b1d5a4fa1bfce837dd0146a))
* **playback:** remove safari user agent check ([e1a2a12](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e1a2a1293a86278edca4616d2a0b6ba14c42d867))
* **player:** upgrade @deezer/deezer-kmp-player to 0.22.1 ([2254d4a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2254d4a7ee7901e3430d8232bbbcc032be769fa8))


### BREAKING CHANGES

* **player:** emove `index` parameter from `set` method in SDKQueue class





# [1.0.0-beta.36](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.35...@deezer/sdk-player@1.0.0-beta.36) (2022-02-23)


### Bug Fixes

* **types:** export PlayerException ([9fe560b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9fe560b1d7fdb66178a3b8c9e3e37d8a89d3d77b))





# [1.0.0-beta.35](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.34...@deezer/sdk-player@1.0.0-beta.35) (2022-02-23)


### Features

* **queue:** add getCurrentMedia method ([c3c3237](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c3c3237f69cb8b3ce81efb591cf2afa2b2d337a1))
* **queue:** update getCurrentMedia ([c390a9f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c390a9f5c807e0d1da195ed7afd461519fa720d7))





# [1.0.0-beta.34](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.33...@deezer/sdk-player@1.0.0-beta.34) (2022-02-21)


### Bug Fixes

* fix some enums issues in StreamLogger ([3d7f2bd](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3d7f2bdc3a50ad0b8047b59d2a06fee3d82d7ba7))





# [1.0.0-beta.33](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.32...@deezer/sdk-player@1.0.0-beta.33) (2022-02-10)


### Bug Fixes

* **context:** fix context object ([87878ae](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/87878ae1e4f460a44b3cd99348c612504fc5cb5c))
* **toggleplay:** handle case when contextType and trackIndex are the same but contextId is different ([b02ddb5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b02ddb52c94afe337a8ec001cef1f1b049197be5))


### Reverts

* Revert "1.0.0" ([1aef194](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1aef194784addc0a6a50701ff4eb29d717f8f764))





# [1.0.0-beta.32](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.31...@deezer/sdk-player@1.0.0-beta.32) (2022-02-02)


### Bug Fixes

* **repeat:** fix toggleRepeat ([3fb70c2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3fb70c2fac9c9386e2ddded6b90f6b5b287504e2))





# [1.0.0-beta.31](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.30...@deezer/sdk-player@1.0.0-beta.31) (2022-01-21)

**Note:** Version bump only for package @deezer/sdk-player





# [1.0.0-beta.30](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.29...@deezer/sdk-player@1.0.0-beta.30) (2022-01-20)


### Bug Fixes

* **dependencies:** move @deezer/graphql-client to devDependencies ([debb3a2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/debb3a21c2345799fe4678ca98e9d2dba9d0d1da))





# [1.0.0-beta.29](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.28...@deezer/sdk-player@1.0.0-beta.29) (2022-01-18)


### Bug Fixes

* **eslint:** disable some rules ([d461f69](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d461f6974387730621cedc28e0f9ee0f10c4b5d8))


### Features

* **graphql:** remove graphql package, move queries and codegen config to player package ([10fd92e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/10fd92e2d86406a7059f94a1eb60227b2dc5b085))





# [1.0.0-beta.28](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.27...@deezer/sdk-player@1.0.0-beta.28) (2022-01-06)


### Bug Fixes

* **sdk-player:** remove isCurrentTrack dependency to current context ([f1b5528](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f1b5528e50b8b791804469d2cc2f4b29f3839bf3))


### Features

* implement the PlayloggerTransientStorage ([ade8e3d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ade8e3d5ac2b2a1b046062f5179fffd3a4986e65))





# [1.0.0-beta.27](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.26...@deezer/sdk-player@1.0.0-beta.27) (2021-12-02)


### Bug Fixes

* fix an issue with NotAllowedError on old browsers ([ded341b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ded341b91ccd2bbb0d8575af63a8a56390da677e))
* fix an issue with repeatType on playlog post 0.19 update ([4a6087e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4a6087e6680c301f3b8f2de8a50f4a25e68f0f9c))
* use LocalStorage when IndexedDB is not available ([c2aeaf2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c2aeaf27157f9e50a3a285febaa5d004089c859b))





# 1.0.0-beta.26 (2021-11-25)


### Bug Fixes

* `isCurrentTrack` returns false when no currentTrack ([43f1b40](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/43f1b407866c7ca15d5358e2a1887e5f673bbe39))
* **auth:** move @deezer/auth to devDependencies ([73ec349](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/73ec34981fb421dea39a58b7c848a607ad5a4808))
* bump sdk-player db version for logs ([d31c9cd](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d31c9cd71c052a05cb65dab1fe5f805a17d36363))
* bump xplayer version for sdk-player ([f2e9c03](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f2e9c039b5234e0496de9f1eef758bc0ddfe8467))
* bundle types ([a133895](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a133895e00948147ae18e49d8dbd64a38f5109b7))
* calls state events at initial subscription ([ff6da45](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ff6da45fba5affcd798a4d5f6d7cc733cad61554))
* changes offer for offerId and make it optional ([e2bf28d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e2bf28d04f6b1ca1f7ec57df31e1c39547b70980))
* changes offer for offerId and make it optional in SDK constructor ([77da404](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/77da4048964fee5d434020f6bcdc2e918aae279b))
* fix typing to always use web-stream-polyfill's types ([1749c9a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1749c9a24c0f1ebf4830a61cca6835410fbe381e))
* **kmp-player:** fix an issue with track token expiration ([3b44365](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3b443657c68af8893d1d42359fdd4e8909eaf2fa))
* **kmp-player:** fix PlaybackState to set READY when accurate ([21ee23b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/21ee23bb89dcbe16162f1868b70c1389a252d350))
* **logcenter:** use only strategy as a default strategy ([6dc807f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6dc807f089857085ea54b562e1f2651f37e54bc0))
* optimize sdk built outpout ([322f9de](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/322f9de7754fccd111255fd045cb89458d36e429))
* **player:** minor typing fixes ([a950383](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a9503837692e260d7defa59c742c6b76d89a9cde))
* **player:** simplify onError handler ([74cff24](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/74cff24110e7f5f1bb99bbaa456e4fc7e6a3425e))
* **renderer-html5:** fix an issue when seeking on a swapped controller ([140fd6c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/140fd6c894eb2478123eef9beb0fb93c422851c1))
* **scripts:** fix release:publish ([a579c34](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a579c346cff6100f6a71b1b0e90fc41d52e2dc20))
* **scripts:** remove useless argument ([f09ef9e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f09ef9e689e4162f5f5c08198c79507f618d0397))
* **sdk-player:** add an event when receiving SIP message, to update the UI ([3ddc1ff](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3ddc1ff82f80064a06dfca84368d94467fb61082))
* **sdk-player:** add support for null mediaFile in renderer.setNext ([6e52255](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6e52255ad259a73b1c969303412798ab642dcb34))
* **sdk-player:** change PlayloggerFactoryStub for PlayloggerFactory ([8261180](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/826118011b09d172dec778e4d5c36f10bf1f07d5))
* **sdk-player:** fix an issue causing the track to be fetched twice ([22bbb9d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/22bbb9db2d151a92eacdba13c1fbb9ffcf9afce2))
* **sdk-player:** fix an issue on natural next in few cases ([c92e99a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c92e99af1e73a2c674a97051fa58d7c97d597e20))
* **sdk-player:** fix an issue where a ReadableStream wasn't closed ([43c9c65](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/43c9c65637600fafe73524c45722cadb263dc1e9))
* **sdk-player:** fix an issue with license token expiration ([e61448a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e61448a3f453366e21ef808d933d6990a3385bf6))
* **sdk-player:** fix typing which where not accessible anymore ([4fa48e6](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4fa48e6e435ffcfea0afff99cb569bbfc262bbe8))
* **sdk-player:** minor typing fixes ([f38d9a6](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f38d9a6335dd725f86479e5a356331a2e0696010))
* **sdk-player:** minor typing fixes ([086028f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/086028fc81c9b485fadf2ee7f4c771eefda33263))
* **sdk-player:** remove archive ([05d4081](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/05d4081a918f2fa87d123c3a9889e38655c42e13))
* **sdk-player:** remove unused import ([f16dcc3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f16dcc3ac90e29abb47e8f719533950d40e9f1f8))
* **sdk-player:** subscribe to SIP channel (oups) ([a4a7d47](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a4a7d47382e19bd6e08c6318e1d8cd50aba8d474))
* use native AbortController if possible ([1f75d3c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1f75d3c46c78b21d3d93a9f9277c4fd76bd77338)), closes [/github.com/mysticatea/abort-controller/issues/10#issuecomment-426934229](https://github.deezerdev.com//github.com/mysticatea/abort-controller/issues/10/issues/issuecomment-426934229)
* use npm 7 workspace ([4838f4f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4838f4fd3be1000f6bdead5c80333b8090d4e2f4))


### chore

* **sdk-player:** update XPlayer @ 0.15 ([68293b2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/68293b2ab4c25620b992b103228dc8f6dd0e8b31))
* **sdk-player:** update XPlayer @ 0.16 ([026b534](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/026b534c3b565ccff3b98f78b9d04dd4a7a6ea38))
* **sdk-player:** update XPlayer @ 0.16.1 ([6daf299](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6daf2992e412bee1f39e3628e613b23a9af63e22))


### Features

* add `sdk-auth` module for sdk authentication ([d37216a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d37216a336cad3546eb7a0042baa023b4d450004))
* add support for infinite queue ([16a763f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/16a763f8003fe003f524f8e42ac4a011f7f2ed6f))
* adds queue available options to the playback state ([b81d143](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b81d143056a8d5b1c9ca179746dadd3de5459a43))
* breaking force consumer to listen events to access state values ([edeb220](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/edeb22065fdf12f63fcf82a7f77fb36a2d24b12b))
* implement TrackMetadataProvider ([5711526](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/571152606bb40c1874109d5378c546883a1acd30))
* **player:** add deezer-media-provider ([caa9d7b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/caa9d7bb75a4f4cd6e769c5b58a36ce218903061))
* **sdk-player:** add a decorator to retrieve client's IP for loggers ([adfda05](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/adfda05ddcf79973a2dca009e675740d2b0b5319))
* **sdk-player:** add action name ([a9ec524](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a9ec5249b7316dad616d9d383de3f5121bfa8ae1))
* **sdk-player:** add PlaybackAttempts logs ([23ea026](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/23ea0260445f6488e73293c3d9bb5b6dea248107))
* **sdk-player:** add PLAYER_ERROR event to sdk-player ([d1dc6c5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d1dc6c534e2e9144762f67baddeec3fe1a9b5acd))
* **sdk-player:** add setVolume, getVolume methods to SDKPlayer ([61f1d02](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/61f1d02d0e6e6e4b557f60918ee80a14b89744fe))
* **sdk-player:** add support for Single Instance Playback messages ([a8c6b70](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a8c6b70fc2287419ea4d6356ba0ec150164c0358))
* **sdk-player:** add the streams logger ([0c6d941](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0c6d941072980dbae078639cd532b8d2f19ae933))
* **sdk-player:** add the support to provide embeded SDKs so it can be logged ([863dfc5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/863dfc5a779dd780312f5605713ae9852dd0dfa3))
* **sdk-player:** handle errors ([cdc7ed6](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/cdc7ed67acc92d0986cf48e077ba7c5c29cbd281))
* **sdk-player:** make SDKPlayer init async, adapt constructor to add token providers ([48aa59a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/48aa59a676c7a0d18fe3cb22a9d0f8d61b6a76b5))
* **sdk-player:** make the LogCenter available for the SDK ([935bbba](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/935bbba8d920cff683999a3529dabe9412feb7bb))
* **sdk-player:** modify remove and add to queue methods to match KMP more closely ([dc34890](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/dc34890ab403a1130c98c3c11b2cddb07cc7b7a0))
* **sdk-player:** remove now useless DummyProvider ([c2afd73](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c2afd73cb4287a837354b3bc2a7f7835408e9f31))
* **sdk-player:** send PlaybackAttempsMetrics logs using LogCenter ([8572c11](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8572c116899fc8db26399c207ccb78f5104c5ca9))
* **sdk-player:** send PlaybackErrors logs using LogCenter ([ae4abab](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ae4abab13d99872068840d609b1536df26ab594f))
* **sdk-player:** update kmp lib to 0.10.0 ([b8e5fec](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b8e5fecc882b2dccb7fea692f217fa953827862e))
* **sdk-player:** upgrade KMP library to 0.8.0 ([ee52dc0](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ee52dc0e861f871c8214f6f3f3471b8ef57af988))
* **sdk-player:** upgrade KMPP XPlayer ([da5e836](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/da5e8368de6272cfc2a201e72210d5c9ed356ea7))
* **sdk-player:** use MediaChecker and IntegrityChecker in order to report playback issues ([4339a11](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4339a113525de8f657dece14835ecba7a42bb733))
* update XPlayer @ 0.17.0 ([c74e0f8](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c74e0f86198832c442e380cc3a1d2e6e2c7e7ee2))


### BREAKING CHANGES

* Remove some field of the `MediaFile` and `MediaRequest`:

	`id` should be changed by mediaId
	`trackI` dand `type` are removed from MediaFile
	`md5` is removed from MediaRequest
* **sdk-player:** SingleInstancePlaybackManager is not constructible anymore,
use SingleInstancePlaybackManager.create() instead.
* **sdk-player:** XPlayer now doesn't expose a Player class anymore, use PlayerFactory.create() instead.
* **sdk-player:** XPlayer now uses `Playable` instead of `MediaRequest`.
* **sdk-player:** mediaProvider and renderer are now instantiated inside the SDK, SDKPlayer
constructor now requires the needed parts for thos instantiation and also a RECTokenProvider





# [1.0.0-beta.22](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.21...@deezer/sdk-player@1.0.0-beta.22) (2021-11-08)


### Bug Fixes

* bundle types ([3e05cfc](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3e05cfcf346582907d3854ea69e8f04e43364008))


### Features

* update XPlayer @ 0.17.0 ([a160cd1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a160cd1729d17c00e1839d5a4fbea93342e5d9b7))


### BREAKING CHANGES

* Remove some field of the `MediaFile` and `MediaRequest`:

	`id` should be changed by mediaId
	`trackI` dand `type` are removed from MediaFile
	`md5` is removed from MediaRequest





# [1.0.0-beta.21](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.20...@deezer/sdk-player@1.0.0-beta.21) (2021-11-04)


### Bug Fixes

* **sdk-player:** change PlayloggerFactoryStub for PlayloggerFactory ([cf3779a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/cf3779aa90ec67976738eb64ac858d9732426b2a))





# [1.0.0-beta.20](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.19...@deezer/sdk-player@1.0.0-beta.20) (2021-11-02)


### Bug Fixes

* use native AbortController if possible ([e93dec8](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e93dec898a20a316644c0b1c639414f70553e700)), closes [/github.com/mysticatea/abort-controller/issues/10#issuecomment-426934229](https://github.deezerdev.com//github.com/mysticatea/abort-controller/issues/10/issues/issuecomment-426934229)





# [1.0.0-beta.19](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.18...@deezer/sdk-player@1.0.0-beta.19) (2021-10-29)


### Bug Fixes

* `isCurrentTrack` returns false when no currentTrack ([85a2b6d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/85a2b6dc0061813570d160bd21859ab63e4dceba))
* optimize sdk built outpout ([64b0f21](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/64b0f2115a0f7372730400ac88609b2dfddd0562))
* **sdk-player:** add an event when receiving SIP message, to update the UI ([e4cb96f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e4cb96f1e3c4f5eb22ddc2d65e0be1aeee4156c5))
* **sdk-player:** remove unused import ([fb2fff6](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/fb2fff629fd0c35a187b526f679925e06a326fd2))
* **sdk-player:** subscribe to SIP channel (oups) ([3e5d4ee](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3e5d4ee8ebc53654890cf3e6559c1d92d30f452a))


### Features

* implement TrackMetadataProvider ([763229a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/763229a58959fb82c21c419cf58023587cfa487a))
* **sdk-player:** add action name ([9d1accd](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9d1accd0dd68f0bbca412797fc7df73387e746cd))
* **sdk-player:** add PlaybackAttempts logs ([b6b1526](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b6b15260a47e0d807df9ae4b0f417acc4ad26d23))
* **sdk-player:** send PlaybackAttempsMetrics logs using LogCenter ([af3a22d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/af3a22d3af397db01b1a133a2f5946c350b696b0))





# [1.0.0-beta.18](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.17...@deezer/sdk-player@1.0.0-beta.18) (2021-10-27)


### Bug Fixes

* **kmp-player:** fix PlaybackState to set READY when accurate ([f8e5037](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f8e5037049704d7cc12a8becba00065824875b8a))


### chore

* **sdk-player:** update XPlayer @ 0.16 ([7eca44c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/7eca44cd37cce725393ed7d8c21f0d04e65387dd))
* **sdk-player:** update XPlayer @ 0.16.1 ([296fe2d](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/296fe2d7b362c36123d2a309e426c55cad86c30e))


### Features

* **sdk-player:** add support for Single Instance Playback messages ([40df5fa](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/40df5faddc2cffa2203944e8adfac706af29a800))


### BREAKING CHANGES

* **sdk-player:** SingleInstancePlaybackManager is not constructible anymore,
use SingleInstancePlaybackManager.create() instead.
* **sdk-player:** XPlayer now doesn't expose a Player class anymore, use PlayerFactory.create() instead.





# [1.0.0-beta.17](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.16...@deezer/sdk-player@1.0.0-beta.17) (2021-10-22)


### Bug Fixes

* **sdk-player:** minor typing fixes ([c063818](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c0638183bc03386840aaca30f049a31d4917fdc8))





# [1.0.0-beta.16](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.15...@deezer/sdk-player@1.0.0-beta.16) (2021-10-19)


### Bug Fixes

* **kmp-player:** fix an issue with track token expiration ([34b11a9](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/34b11a99f7dd1d8588871b593e5c83f22435abbd))
* **sdk-player:** fix an issue with license token expiration ([59a6f07](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/59a6f07fa0417965c174c1f79301a343b04c646b))
* **sdk-player:** fix typing which where not accessible anymore ([dcebdae](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/dcebdae9d53b2c3a28ba40b691c09d8ce55908f5))


### chore

* **sdk-player:** update XPlayer @ 0.15 ([eb44371](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/eb44371eadf937a46138781d2d32261ae40007eb))


### Features

* **sdk-player:** add a decorator to retrieve client's IP for loggers ([d668254](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d668254f71df341b2e261229c5606d1ec0d0eb27))
* **sdk-player:** add the support to provide embeded SDKs so it can be logged ([d53db02](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d53db0240c1ca4a60987d621be157a2f38e540d5))
* **sdk-player:** send PlaybackErrors logs using LogCenter ([5628a07](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5628a076983f74bb1995fef9ca057d9ef46842dc))


### BREAKING CHANGES

* **sdk-player:** XPlayer now uses `Playable` instead of `MediaRequest`.





# [1.0.0-beta.15](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.14...@deezer/sdk-player@1.0.0-beta.15) (2021-10-13)


### Bug Fixes

* **renderer-html5:** fix an issue when seeking on a swapped controller ([a01b416](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a01b4169badeafa3f97356dea05884a9f5a2631e))
* **sdk-player:** fix an issue causing the track to be fetched twice ([f33a3b7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f33a3b7d6d7455c5602c346c22bfde33c55c92fa))
* **sdk-player:** fix an issue on natural next in few cases ([fecb17c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/fecb17c0dcfabd23b72c37af5fb2d785d7a3a0fd))
* **sdk-player:** fix an issue where a ReadableStream wasn't closed ([a147c73](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a147c73d89951fa4e3be21b6a915988a0638c0b0))





# [1.0.0-beta.14](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.13...@deezer/sdk-player@1.0.0-beta.14) (2021-10-13)


### Bug Fixes

* bump sdk-player db version for logs ([db81bf8](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/db81bf87d30918e6efb1a6dc1d6767e5e81b8689))





# [1.0.0-beta.13](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.12...@deezer/sdk-player@1.0.0-beta.13) (2021-10-11)

**Note:** Version bump only for package @deezer/sdk-player





# [1.0.0-beta.12](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.11...@deezer/sdk-player@1.0.0-beta.12) (2021-09-29)


### Features

* **sdk-player:** add the streams logger ([e555959](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e555959e20e01d54ad132e39ca188d341ff574f8))





# [1.0.0-beta.11](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.10...@deezer/sdk-player@1.0.0-beta.11) (2021-09-20)

**Note:** Version bump only for package @deezer/sdk-player





# [1.0.0-beta.10](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.9...@deezer/sdk-player@1.0.0-beta.10) (2021-09-17)


### Bug Fixes

* **sdk-player:** minor typing fixes ([4ac3d06](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4ac3d06b2ede4b658ec5a915829f7ce7f2d1fe54))


### Features

* **sdk-player:** handle errors ([cdf6c75](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/cdf6c759421a9216f460110f76fc67f2278e39c9))
* **sdk-player:** use MediaChecker and IntegrityChecker in order to report playback issues ([d18a2c1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d18a2c17ebb5b5a60081c4b659f98fc19a5bcfaa))





# [1.0.0-beta.9](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.8...@deezer/sdk-player@1.0.0-beta.9) (2021-09-03)


### Bug Fixes

* changes offer for offerId and make it optional in SDK constructor ([fef1ef7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/fef1ef77d90161b05ff8fd0b41b13dbb3fb398f0))





# [1.0.0-beta.8](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.7...@deezer/sdk-player@1.0.0-beta.8) (2021-09-03)


### Bug Fixes

* changes offer for offerId and make it optional ([7006888](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/700688825754ccc495ca4d8a41608fa6d114c2c3))





# [1.0.0-beta.7](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.6...@deezer/sdk-player@1.0.0-beta.7) (2021-09-02)


### Bug Fixes

* **logcenter:** use only strategy as a default strategy ([feb8b39](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/feb8b3905d01b16ff0e8cf14947009dc6d62b051))





# [1.0.0-beta.6](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.5...@deezer/sdk-player@1.0.0-beta.6) (2021-09-02)


### Bug Fixes

* bump xplayer version for sdk-player ([a12a392](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a12a392f32869e63788b02171c1027af62a7a1a3))
* calls state events at initial subscription ([d919db1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d919db1a44d5cdb30604ca0190c69512fb8c775f))
* fix typing to always use web-stream-polyfill's types ([305cb79](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/305cb79b8f5b36a5cdcad09cee956c96caa9f4b6))


### Features

* add support for infinite queue ([f1bc59b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f1bc59b76bb8853194f8b95aed32cdf72f1b2f65))
* adds queue available options to the playback state ([41a53df](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/41a53df821749c8ff99a929af43ab6cf083c1b1c))
* breaking force consumer to listen events to access state values ([14f8f16](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/14f8f1690113f08335c6f8322b43b96e9083c5f1))
* **sdk-player:** make the LogCenter available for the SDK ([1371e29](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1371e29f15593a479e54eb07fc7e7915fc94b142))





# [1.0.0-beta.5](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.4...@deezer/sdk-player@1.0.0-beta.5) (2021-08-25)

**Note:** Version bump only for package @deezer/sdk-player





# [1.0.0-beta.4](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.3...@deezer/sdk-player@1.0.0-beta.4) (2021-08-20)


### Features

* **sdk-player:** update kmp lib to 0.10.0 ([2c1db32](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2c1db32e514cbd27af02d9c90f4acbf1d38cc7a9))





# [1.0.0-beta.3](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.2...@deezer/sdk-player@1.0.0-beta.3) (2021-08-18)


### Bug Fixes

* use npm 7 workspace ([b32b671](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b32b67136a611198f6bc83f055ec9380409970c5))





# [1.0.0-beta.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.1...@deezer/sdk-player@1.0.0-beta.2) (2021-08-12)


### Features

* **sdk-player:** upgrade KMP library to 0.8.0 ([d07b780](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d07b7803ded27040e17a4652ea974fd131b82952))





# [1.0.0-beta.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@1.0.0-beta.0...@deezer/sdk-player@1.0.0-beta.1) (2021-08-11)

**Note:** Version bump only for package @deezer/sdk-player





# [1.0.0-beta.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@0.5.0-beta.13...@deezer/sdk-player@1.0.0-beta.0) (2021-08-06)


### Features

* **sdk-player:** add PLAYER_ERROR event to sdk-player ([838e12a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/838e12a379a62541bdb94de0f80173f05b9f3029))
* **sdk-player:** make SDKPlayer init async, adapt constructor to add token providers ([921d8e1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/921d8e10d6589bb30f49b5af282acead19d4cedf))


### BREAKING CHANGES

* **sdk-player:** mediaProvider and renderer are now instantiated inside the SDK, SDKPlayer
constructor now requires the needed parts for thos instantiation and also a RECTokenProvider





# [0.5.0-beta.13](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@0.5.0-beta.12...@deezer/sdk-player@0.5.0-beta.13) (2021-08-06)

**Note:** Version bump only for package @deezer/sdk-player





# [0.5.0-beta.12](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@0.5.0-beta.11...@deezer/sdk-player@0.5.0-beta.12) (2021-08-04)

**Note:** Version bump only for package @deezer/sdk-player





# [0.5.0-beta.11](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@0.5.0-beta.10...@deezer/sdk-player@0.5.0-beta.11) (2021-08-03)


### Bug Fixes

* **player:** minor typing fixes ([57c3dab](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/57c3dab156a9646b611a0e6dd63ba57ea91e3c21))
* **sdk-player:** add support for null mediaFile in renderer.setNext ([8af11c0](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/8af11c0db2abcfb2525037c2e002e04e679a69ff))


### Features

* **sdk-player:** remove now useless DummyProvider ([6b298a9](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6b298a9e828cb09e22b2db06889640b9fb9964c9))
* **sdk-player:** upgrade KMPP XPlayer ([67e1fe7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/67e1fe77321f9b9976d25e85a779f986824bcd59))





# [0.5.0-beta.10](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@0.5.0-beta.9...@deezer/sdk-player@0.5.0-beta.10) (2021-07-29)


### Features

* **player:** add deezer-media-provider ([5b659aa](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5b659aa2dce8106fdab52ff86443896fa86ed976))





# [0.5.0-beta.9](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@0.5.0-beta.8...@deezer/sdk-player@0.5.0-beta.9) (2021-07-28)


### Bug Fixes

* **player:** simplify onError handler ([149499e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/149499eda0d7ab57c178c6b8c4f77b33c195cf23))





# [0.5.0-beta.8](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@0.5.0-beta.7...@deezer/sdk-player@0.5.0-beta.8) (2021-07-26)


### Features

* **sdk-player:** add setVolume, getVolume methods to SDKPlayer ([1318c67](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1318c6784abde1d4daee205d1ac67a5d9d61331d))
* **sdk-player:** modify remove and add to queue methods to match KMP more closely ([afe4086](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/afe40865b136969800c138f01cf12a9aa21f3c59))





# [0.5.0-beta.7](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@0.5.0-beta.6...@deezer/sdk-player@0.5.0-beta.7) (2021-07-26)

**Note:** Version bump only for package @deezer/sdk-player





# [0.5.0-beta.6](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@0.5.0-beta.5...@deezer/sdk-player@0.5.0-beta.6) (2021-07-22)


### Features

* add `sdk-auth` module for sdk authentication ([5cc4aa9](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5cc4aa9c9980fad618833f3eec0fe8dcd5c7865f))





# [0.5.0-beta.5](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-player@0.5.0-beta.4...@deezer/sdk-player@0.5.0-beta.5) (2021-07-21)


### Bug Fixes

* **sdk-player:** queue repeat mode is reattached after queue flush and togglePlay improvement ([c5d795b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/c5d795b7c60f8e0fc9d8616075e50bf4199f88e6))


### Features

* **sdk-player:** add queue manipulation apis add, remove, shuffle and repeat ([3b9be38](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3b9be38ecabbfdb8343e91e7d16b7f840748256e))





# 0.5.0-beta.4 (2021-07-20)

**Note:** Version bump only for package @deezer/sdk-player
