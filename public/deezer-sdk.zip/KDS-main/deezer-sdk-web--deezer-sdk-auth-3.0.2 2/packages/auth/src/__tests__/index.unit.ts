import {DeezerAuth} from '../';

describe('auth module', () => {
	it('should not throw when instantiated', () => {
		expect(() => {
			new DeezerAuth({host: 'AUTH_DOMAIN'});
		}).not.toThrow();
	});
});
