import {AuthBase, WithCredentialsLogin, WithPartnerLogin} from '@deezer/auth';

export const DeezerAuth = WithCredentialsLogin(WithPartnerLogin(AuthBase));
