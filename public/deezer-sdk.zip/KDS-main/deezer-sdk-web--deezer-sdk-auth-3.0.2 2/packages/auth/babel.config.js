module.exports = function getBabelConfig(api) {
	api.cache(true);

	const presets = ['@babel/preset-env', '@babel/preset-typescript'];

	const plugins = ['@babel/plugin-transform-runtime'];

	return {
		ignore: ['**/__tests__/**/*'],
		plugins,
		presets,
	};
};
