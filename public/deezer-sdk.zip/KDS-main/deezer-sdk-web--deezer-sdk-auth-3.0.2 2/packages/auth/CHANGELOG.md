# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [3.0.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@3.0.1...@deezer/sdk-auth@3.0.2) (2025-07-24)


### Bug Fixes

* add package-json-from-dist dependency to auth package ([32c93d2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/32c93d2846a4515ba529a07a1d9ffa66cb1c21cd))
* add package-json-from-dist dependency to main package ([b81ee9c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b81ee9c5169bbf774d4da2cc97a38d7e45fdfc0b))
* add rimraf to auth package ([66cb8b2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/66cb8b268e00280a22a595c0384b8311b4a07d46))





## [3.0.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.6.4...@deezer/sdk-auth@3.0.1) (2024-12-13)

**Note:** Version bump only for package @deezer/sdk-auth





## [2.6.4](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.6.3...@deezer/sdk-auth@2.6.4) (2023-03-03)


### Bug Fixes

* explicit of export storage type ([d08892b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d08892bcf17a7fd8444a7e86fe9250cc11ef0670))
* export as SDKStorage ([ff3151b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ff3151b24dbe29ecb4b768365a822e6b2113f2df))
* export everything ([5feadc2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5feadc2d7e4cd81276bcaf743348925cee70e648))
* import type instead of class ([6a1fe6a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6a1fe6a4f488ca4df234cf56efb3abd3356188ab))
* move @deezer/auth to devDependencies ([5df091f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5df091f6687493a4676afefa5a4bb5ac605b60fa))
* remove @deezer/storage ([1ed6b47](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1ed6b471d0f31f6064e355dd03be59cc10cbc0a9))
* storage export ([2a7f633](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2a7f633b9f35f91789bf1dc4860ca1c6a8dc43b2))





## [2.6.3](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.6.2...@deezer/sdk-auth@2.6.3) (2023-03-03)


### Bug Fixes

* export missing types from @deezer/storage ([29b72a5](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/29b72a5c263ef90aab02dd435ab8d6cefda256b0))
* move @deezer/auth to devDependencies ([a56051c](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a56051cb07a50d71565ff4135c67d3a6a60fbbcb))
* remove duplicate package ([ee19227](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ee192273372e13e1cfa7b16a81c89f3bf0f6977b))





## [2.6.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.6.1...@deezer/sdk-auth@2.6.2) (2023-03-02)


### Bug Fixes

* move @deezer/auth to devDependencies ([e04b3db](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e04b3dbf2e6ebab53ff7e75d025e4b9f2e2606fd))





## [2.6.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.6.0...@deezer/sdk-auth@2.6.1) (2023-03-01)


### Bug Fixes

* remove log ([1afcfa6](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/1afcfa67213d4514bc8947ac9956a8527c5d0c81))





# [2.6.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.5.5...@deezer/sdk-auth@2.6.0) (2023-02-28)


### Bug Fixes

* add log ([555d2b2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/555d2b2bdc718c1c70414a852e1e5050b0fa864d))
* add named export for LocalStorage ([0d0268b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/0d0268b85cef82d9e76b9089b0b9292aa87aa251))
* export from storage module ([a1d1f16](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/a1d1f16a39b04d7733074b9d68d34c89c9ae7a55))
* exports ([d8054a4](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d8054a4c4ff5fd145e75fefa70863003e8939606))
* prettier ([3601b1a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/3601b1a879efaee4a2933f9ef943bdc6e306f457))
* remove definitions files ([9478956](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/9478956c5d13507d7a78f805fcaf4170ffa2a6b8))
* typings ([07b30eb](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/07b30ebfb51aa67da537df30c68b1409fca30119))
* update export ([7017243](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/701724332b01c3fdc4a3f22156f0a5c03545d9f8))
* update export ([32c5a29](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/32c5a298d95d33a2d0a86d159cc0ead63b4cce66))


### Features

* add localstorage for refresh token ([98183a1](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/98183a19935a79719283df0e71d676f40d059fc9))





## [2.5.5](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.5.4...@deezer/sdk-auth@2.5.5) (2022-10-13)

**Note:** Version bump only for package @deezer/sdk-auth





## [2.5.4](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.5.3...@deezer/sdk-auth@2.5.4) (2022-09-01)


### Reverts

* Revert "chore(release): publish packages" ([ef1ff28](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ef1ff283fdbbf823d5a6bfc483570293a4aa037b))





## [2.5.3](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.5.2...@deezer/sdk-auth@2.5.3) (2022-08-26)

**Note:** Version bump only for package @deezer/sdk-auth





## [2.5.2](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.5.1...@deezer/sdk-auth@2.5.2) (2022-08-08)

**Note:** Version bump only for package @deezer/sdk-auth





## [2.5.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.5.0...@deezer/sdk-auth@2.5.1) (2022-06-24)

**Note:** Version bump only for package @deezer/sdk-auth





# [2.5.0](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@2.4.1...@deezer/sdk-auth@2.5.0) (2022-04-28)


### Features

* **CI:** create CI job for external release ([2a21c18](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2a21c18e60a421be4cdc745fec855964b22b7394))





## [2.4.1](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@1.0.0-beta.33...@deezer/sdk-auth@2.4.1) (2022-04-26)

**Note:** Version bump only for package @deezer/sdk-auth





# [1.0.0-beta.33](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@1.0.0-beta.32...@deezer/sdk-auth@1.0.0-beta.33) (2022-03-30)


### Bug Fixes

* **scripts:** fix watch scripts ([2318cd2](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/2318cd28dcbe13e7cb6628cf550ef7ac7a1e6c0d))
* **watch:** add watch build inside packages ([f9db790](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/f9db7900d48ecf461d64123871ee1542da744401))





# [1.0.0-beta.32](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@1.0.0-beta.31...@deezer/sdk-auth@1.0.0-beta.32) (2022-03-02)

**Note:** Version bump only for package @deezer/sdk-auth





# [1.0.0-beta.31](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@1.0.0-beta.30...@deezer/sdk-auth@1.0.0-beta.31) (2022-01-06)

**Note:** Version bump only for package @deezer/sdk-auth





# [1.0.0-beta.30](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@1.0.0-beta.29...@deezer/sdk-auth@1.0.0-beta.30) (2021-12-02)

**Note:** Version bump only for package @deezer/sdk-auth





# [1.0.0-beta.29](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@1.0.0-beta.26...@deezer/sdk-auth@1.0.0-beta.29) (2021-11-25)


### Bug Fixes

* **dependencies:** add api extractor ([026d2e8](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/026d2e88d2eeaf656c27ac248d076d912575db59))
* **package.json:** fix files array ([6631ecc](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6631eccf42c6354ea551064cca87cea0515762c1))
* **package.json:** update package.json ([65a11c7](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/65a11c739196859b3585ab72a68e618100bca3a2))





# 1.0.0-beta.26 (2021-11-25)


### Bug Fixes

* **auth:** move @deezer/auth to devDependencies ([73ec349](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/73ec34981fb421dea39a58b7c848a607ad5a4808))
* use npm 7 workspace ([4838f4f](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/4838f4fd3be1000f6bdead5c80333b8090d4e2f4))


### Features

* add `sdk-auth` module for sdk authentication ([d37216a](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d37216a336cad3546eb7a0042baa023b4d450004))
* **auth:** add WithPartnerLogin and WithCredentialsLogin to auth methods ([eb28d2b](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/eb28d2b166fa3c14be3f1faa8bb5145e28170bf5))
* **auth:** switch auth mode to WithAnonymousLogin from WithPartnerLogin ([e9e91e3](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/e9e91e3db77cd9c3f3f12fde7b69f1c0b2cc841f))
* **sdk-auth:** build sdk-auth from new auth mixins ([6719e7e](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/6719e7e4b87c2cbcaf36714b9fe608661c576c24))
* **sdk-player:** upgrade KMP library to 0.8.0 ([ee52dc0](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/ee52dc0e861f871c8214f6f3f3471b8ef57af988))





# [0.1.0-beta.22](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.21...@deezer/sdk-auth@0.1.0-beta.22) (2021-11-08)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.21](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.20...@deezer/sdk-auth@0.1.0-beta.21) (2021-11-04)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.20](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.19...@deezer/sdk-auth@0.1.0-beta.20) (2021-11-02)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.19](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.18...@deezer/sdk-auth@0.1.0-beta.19) (2021-10-27)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.18](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.17...@deezer/sdk-auth@0.1.0-beta.18) (2021-10-22)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.17](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.16...@deezer/sdk-auth@0.1.0-beta.17) (2021-10-19)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.16](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.15...@deezer/sdk-auth@0.1.0-beta.16) (2021-10-11)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.15](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.14...@deezer/sdk-auth@0.1.0-beta.15) (2021-09-20)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.14](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.13...@deezer/sdk-auth@0.1.0-beta.14) (2021-09-17)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.13](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.12...@deezer/sdk-auth@0.1.0-beta.13) (2021-08-25)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.12](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.11...@deezer/sdk-auth@0.1.0-beta.12) (2021-08-18)


### Bug Fixes

* use npm 7 workspace ([b32b671](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/b32b67136a611198f6bc83f055ec9380409970c5))





# [0.1.0-beta.11](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.10...@deezer/sdk-auth@0.1.0-beta.11) (2021-08-12)


### Features

* **sdk-player:** upgrade KMP library to 0.8.0 ([d07b780](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/d07b7803ded27040e17a4652ea974fd131b82952))





# [0.1.0-beta.10](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.9...@deezer/sdk-auth@0.1.0-beta.10) (2021-08-11)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.9](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.8...@deezer/sdk-auth@0.1.0-beta.9) (2021-08-06)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.8](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.7...@deezer/sdk-auth@0.1.0-beta.8) (2021-08-06)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.7](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.6...@deezer/sdk-auth@0.1.0-beta.7) (2021-08-04)


### Features

* **sdk-auth:** build sdk-auth from new auth mixins ([80ee5de](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/80ee5de3f2246211f8e3211d4ccb911ddca30875))





# [0.1.0-beta.6](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.5...@deezer/sdk-auth@0.1.0-beta.6) (2021-08-03)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.5](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.4...@deezer/sdk-auth@0.1.0-beta.5) (2021-07-29)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.4](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.3...@deezer/sdk-auth@0.1.0-beta.4) (2021-07-28)

**Note:** Version bump only for package @deezer/sdk-auth





# [0.1.0-beta.3](https://github.deezerdev.com/Partnership/deezer-sdk-web/compare/@deezer/sdk-auth@0.1.0-beta.2...@deezer/sdk-auth@0.1.0-beta.3) (2021-07-26)

**Note:** Version bump only for package @deezer/sdk-auth





# 0.1.0-beta.2 (2021-07-22)


### Features

* add `sdk-auth` module for sdk authentication ([5cc4aa9](https://github.deezerdev.com/Partnership/deezer-sdk-web/commit/5cc4aa9c9980fad618833f3eec0fe8dcd5c7865f))
