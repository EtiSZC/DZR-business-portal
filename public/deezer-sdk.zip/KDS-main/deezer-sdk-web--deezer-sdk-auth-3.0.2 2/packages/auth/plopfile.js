module.exports = (
	/** @type {import('plop').NodePlopAPI} */
	plop,
) => {
	plop.setGenerator('pps-npmrc', {
		description: 'Generate partnership npmrc',
		prompts: [
			{
				type: 'input',
				name: 'email',
				validate: (s) => !!s.length,
				message: 'DeezerPPS JFrog email',
			},
			{
				type: 'input',
				name: 'username',
				validate: (s) => !!s.length,
				message: 'DeezerPPS JFrog username',
				filter: (username) => new Buffer.from(username).toString('base64'),
			},
			{
				type: 'input',
				name: 'password',
				validate: (s) => !!s.length,
				message: 'DeezerPPS JFrog password',
				filter: (password) => new Buffer.from(password).toString('base64'),
			},
		],
		actions: [
			{
				type: 'add',
				path: './pps.npmrc',
				templateFile: './scripts/templates/pps.npmrc.hbs',
				force: true,
			},
		],
	});
};
