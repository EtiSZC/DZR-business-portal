# `sdk-auth`

Deezer Web SDK

## Installation

```
npm i @deezer/sdk-auth
```

[## Usage](https://github.deezerdev.com/Deezer/deezerlib/tree/master/packages/core/auth)

# Release

## Releasing for partners

Releases are made locally for now, you need to prepare your environment for the release (see section below)

### Releasing (requires preparing environment)

- Change the sdk-player `package.json` version number
- Run `npm run build` and then `npm run release` in `sdk-player` directory

### Prepare your environment for the release

[DeezerPPS JFrog Registry](https://deezerpps.jfrog.io/ui/repos/tree/General/web-sdk)

- Create an account on the DeezerPPS registry
- Ask Partnership Integration (Camille Blin) to give your account read&write access for web-sdk package
- Initialize your custom pps.npmrc: `npm run generate:npmrc` in `sdk-auth` directory

> Note: cannot use `lerna run` for this command because it prompts in terminal questions
